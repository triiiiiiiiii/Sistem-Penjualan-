-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Aug 30, 2023 at 12:41 PM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 7.3.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ta_angge`
--

-- --------------------------------------------------------

--
-- Table structure for table `jumlah_produk_transaksi`
--

CREATE TABLE `jumlah_produk_transaksi` (
  `id_jumlah_produk` int(11) NOT NULL,
  `id_transaksi` int(11) NOT NULL,
  `id_produk` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  `harga` int(25) NOT NULL,
  `total_harga` int(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `jumlah_produk_transaksi`
--

INSERT INTO `jumlah_produk_transaksi` (`id_jumlah_produk`, `id_transaksi`, `id_produk`, `qty`, `harga`, `total_harga`) VALUES
(1, 1, 3, 5, 6000, 30000),
(2, 2, 1, 5, 8000, 40000),
(3, 2, 2, 5, 6000, 30000),
(4, 2, 6, 5, 5000, 25000),
(5, 3, 2, 5, 6000, 30000),
(6, 4, 1, 5, 8000, 40000),
(7, 5, 3, 3, 6000, 18000),
(8, 5, 1, 3, 8000, 24000),
(9, 5, 2, 3, 6000, 18000),
(10, 5, 6, 3, 5000, 15000),
(11, 6, 2, 2, 6000, 12000),
(12, 6, 3, 2, 6000, 12000);

-- --------------------------------------------------------

--
-- Table structure for table `keranjang`
--

CREATE TABLE `keranjang` (
  `id_keranjang` int(11) NOT NULL,
  `id_produk` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  `harga` int(11) NOT NULL,
  `total_harga` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `keranjang`
--

INSERT INTO `keranjang` (`id_keranjang`, `id_produk`, `qty`, `harga`, `total_harga`) VALUES
(37, 3, 5, 6000, 30000);

-- --------------------------------------------------------

--
-- Table structure for table `laporan`
--

CREATE TABLE `laporan` (
  `id_laporan` int(11) NOT NULL,
  `tgl_laporan` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `laporan`
--

INSERT INTO `laporan` (`id_laporan`, `tgl_laporan`) VALUES
(1, '2023-08-25'),
(2, '2023-08-26'),
(4, '2023-08-27'),
(5, '2023-07-28');

-- --------------------------------------------------------

--
-- Table structure for table `pelanggan`
--

CREATE TABLE `pelanggan` (
  `id_pelanggan` int(11) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `telefon` varchar(15) NOT NULL,
  `alamat` varchar(100) NOT NULL,
  `status` enum('aktif','nonaktif') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pelanggan`
--

INSERT INTO `pelanggan` (`id_pelanggan`, `nama`, `email`, `telefon`, `alamat`, `status`) VALUES
(11, 'Angge tri', 'anggetri80@gmail.com', '0813-1707-0829', 'jakarta barat', 'nonaktif'),
(12, 'Anak Mama Sekali', 'admin@gmail.com', '0813-1707-0829', 'Jl.ujung harapan', 'aktif'),
(13, 'Abdul Gofur Rohdisam', 'admin@gmail.com', '0813-1707-0829', 'Jl.ujung harapan', 'aktif'),
(14, 'Angge tri wibowo', 'anggetri80@gmail.com', '0813-1707-0829', 'Jl.ujung harapan', 'nonaktif'),
(15, 'Angge tri wibowo', 'staff@gmail.com', '0813-1707-0829', 'Jl.ujung harapan', 'aktif'),
(16, 'Angge tri wibowo', 'admin@easywms.com', '0813-1707-0829', 'Jl.ujung harapan', 'aktif'),
(17, 'Angge tri wibowo', 'admin@gmail.com', '0813-1707-0829', 'bekasi', 'aktif'),
(18, 'Angge tri wibowo', 'admin@gmail.com', '0813-1707-0829', 'Jl.ujung harapan', 'nonaktif'),
(19, 'Angge tri wibowo', 'admin@gmail.com', '0813-1707-0829', 'Jl.ujung harapan', 'nonaktif');

-- --------------------------------------------------------

--
-- Table structure for table `pengiriman`
--

CREATE TABLE `pengiriman` (
  `id_pengiriman` int(11) NOT NULL,
  `tgl_kirim` datetime NOT NULL,
  `tgl_sampai` datetime NOT NULL,
  `id_transaksi` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pengiriman`
--

INSERT INTO `pengiriman` (`id_pengiriman`, `tgl_kirim`, `tgl_sampai`, `id_transaksi`) VALUES
(2, '2023-08-29 11:56:37', '2023-08-30 09:39:39', 2),
(3, '2023-08-30 09:21:32', '2023-08-30 09:40:18', 1),
(4, '2023-08-30 09:33:39', '2023-08-30 09:42:24', 3),
(5, '2023-08-30 09:45:08', '0000-00-00 00:00:00', 4),
(6, '2023-08-30 09:55:33', '0000-00-00 00:00:00', 5),
(7, '2023-08-30 09:58:08', '0000-00-00 00:00:00', 6);

-- --------------------------------------------------------

--
-- Table structure for table `produk`
--

CREATE TABLE `produk` (
  `id_produk` int(11) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `stok` int(11) NOT NULL,
  `harga` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `produk`
--

INSERT INTO `produk` (`id_produk`, `nama`, `stok`, `harga`) VALUES
(1, 'Intip Madu ', 7, 8000),
(2, 'Intip Besar Manis', 0, 6000),
(3, 'Intip Besar Asin', 0, 6000),
(6, 'Intip Madu Asin', 2, 5000);

-- --------------------------------------------------------

--
-- Table structure for table `produk_masuk`
--

CREATE TABLE `produk_masuk` (
  `id_produk_masuk` int(11) NOT NULL,
  `id_produk` int(11) NOT NULL,
  `tanggal_masuk` date NOT NULL,
  `stok_masuk` int(11) NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `produk_masuk`
--

INSERT INTO `produk_masuk` (`id_produk_masuk`, `id_produk`, `tanggal_masuk`, `stok_masuk`, `user_id`) VALUES
(1, 1, '2023-08-07', 2, 0),
(2, 1, '2023-08-07', 3, 0),
(3, 1, '2023-08-07', 2, 1),
(4, 1, '2023-08-07', 3, 1),
(5, 6, '2023-08-08', 8, 1),
(6, 1, '2023-08-27', 10, 2),
(7, 2, '2023-08-27', 5, 2),
(8, 3, '2023-08-28', 10, 2);

-- --------------------------------------------------------

--
-- Table structure for table `transaksi`
--

CREATE TABLE `transaksi` (
  `id_transaksi` int(11) NOT NULL,
  `tgl_transaksi` datetime NOT NULL,
  `id_user` int(11) NOT NULL,
  `id_pelanggan` int(11) NOT NULL,
  `total_belanja` int(25) NOT NULL,
  `diskon` int(25) NOT NULL,
  `grand_total` int(25) NOT NULL,
  `bayar` int(25) NOT NULL,
  `kembalian` int(25) NOT NULL,
  `status_pengiriman` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `transaksi`
--

INSERT INTO `transaksi` (`id_transaksi`, `tgl_transaksi`, `id_user`, `id_pelanggan`, `total_belanja`, `diskon`, `grand_total`, `bayar`, `kembalian`, `status_pengiriman`) VALUES
(1, '2023-08-25 22:11:08', 2, 11, 30000, 0, 30000, 50000, 20000, 2),
(2, '2023-08-25 22:11:51', 2, 11, 95000, 0, 95000, 100000, 5000, 2),
(3, '2023-08-26 15:04:09', 2, 11, 30000, 0, 30000, 30000, 0, 2),
(4, '2023-08-27 00:08:52', 2, 12, 40000, 20000, 20000, 20000, 0, 1),
(5, '2023-07-28 10:51:58', 2, 14, 75000, 5000, 70000, 100000, 30000, 1),
(6, '2023-07-28 10:53:57', 2, 13, 24000, 0, 24000, 30000, 6000, 1);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `user_id` int(11) NOT NULL,
  `user_name` varchar(50) NOT NULL,
  `user_email` varchar(50) NOT NULL,
  `user_password` varchar(300) NOT NULL,
  `user_akses` int(11) NOT NULL,
  `user_status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `user_name`, `user_email`, `user_password`, `user_akses`, `user_status`) VALUES
(1, 'Angge Tri Wibowo', 'admin@gmail.com', 'b759497cf50772b2452434b3983eebcc1772f1e03bbd76dc2a139da7', 1, 1),
(2, 'Muhammad Hatta', 'staff@gmail.com', 'bd8afa4b4a197101a884333dcc0a817c671b168e9d6eadb16dc02a95', 2, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `jumlah_produk_transaksi`
--
ALTER TABLE `jumlah_produk_transaksi`
  ADD PRIMARY KEY (`id_jumlah_produk`);

--
-- Indexes for table `keranjang`
--
ALTER TABLE `keranjang`
  ADD PRIMARY KEY (`id_keranjang`);

--
-- Indexes for table `laporan`
--
ALTER TABLE `laporan`
  ADD PRIMARY KEY (`id_laporan`);

--
-- Indexes for table `pelanggan`
--
ALTER TABLE `pelanggan`
  ADD PRIMARY KEY (`id_pelanggan`);

--
-- Indexes for table `pengiriman`
--
ALTER TABLE `pengiriman`
  ADD PRIMARY KEY (`id_pengiriman`);

--
-- Indexes for table `produk`
--
ALTER TABLE `produk`
  ADD PRIMARY KEY (`id_produk`);

--
-- Indexes for table `produk_masuk`
--
ALTER TABLE `produk_masuk`
  ADD PRIMARY KEY (`id_produk_masuk`);

--
-- Indexes for table `transaksi`
--
ALTER TABLE `transaksi`
  ADD PRIMARY KEY (`id_transaksi`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `jumlah_produk_transaksi`
--
ALTER TABLE `jumlah_produk_transaksi`
  MODIFY `id_jumlah_produk` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `keranjang`
--
ALTER TABLE `keranjang`
  MODIFY `id_keranjang` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT for table `laporan`
--
ALTER TABLE `laporan`
  MODIFY `id_laporan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `pelanggan`
--
ALTER TABLE `pelanggan`
  MODIFY `id_pelanggan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `pengiriman`
--
ALTER TABLE `pengiriman`
  MODIFY `id_pengiriman` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `produk`
--
ALTER TABLE `produk`
  MODIFY `id_produk` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `produk_masuk`
--
ALTER TABLE `produk_masuk`
  MODIFY `id_produk_masuk` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `transaksi`
--
ALTER TABLE `transaksi`
  MODIFY `id_transaksi` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
