<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard_model extends CI_Model {

    public function pelanggan_jumlah()
    {
        $this->db->select('COUNT(id_pelanggan) as jumlah_pelanggan');
        $this->db->from('pelanggan');
        return $this->db->get()->result();
    }

    public function produk_jumlah()
    {
        $this->db->select('COUNT(id_produk) as jumlah_produk');
        $this->db->from('produk');
        return $this->db->get()->result();
    }

    public function transaksi_jumlah()
    {
        $this->db->select('COUNT(id_transaksi) as jumlah_transaksi');
        $this->db->from('transaksi');
        return $this->db->get()->result();
    }

    public function transaksi_jumlah_total()
    {
        $this->db->select('SUM(grand_total) as grand_total');
        $this->db->from('transaksi');
        return $this->db->get()->result();
    }
    
}
 