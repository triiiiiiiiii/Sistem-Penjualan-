<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class UserModel extends CI_Model {


    public function get_user() {
        $query = $this->db->get('user');
        return $query->result();
    }

    public function get_user_edit($id)
    {
        $this->db->select('*');
        $this->db->from('user');
        $this->db->where('user_id', $id);
        return $this->db->get()->result();
    }

    public function user_add($data)
    {
        $this->db->insert('user', $data);
    }

    public function user_edit_act($data, $id)
    {
        $this->db->where('user_id', $id);
        $this->db->update('user', $data);
    }

    function user_hapus($id)
    {
        $this->db->where('user_id', $id);
        $this->db->delete('user');
    }
    
}
 