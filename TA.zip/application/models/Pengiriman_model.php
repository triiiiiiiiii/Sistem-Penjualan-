<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Pengiriman_model extends CI_Model
{
    public function get_pengiriman()
    {
        $this->db->select('*');
        $this->db->from('pengiriman');
        $this->db->join('transaksi', 'transaksi.id_transaksi=pengiriman.id_transaksi');
        $this->db->join('pelanggan', 'pelanggan.id_pelanggan=transaksi.id_pelanggan');
        $this->db->join('user', 'user.user_id=transaksi.id_user');
        $this->db->order_by('pengiriman.id_pengiriman', 'DESC');
        return $this->db->get()->result();
    }

    public function pengiriman_detail($id)
    {
        $this->db->select('*');
        $this->db->select('COUNT(id_jumlah_produk) as jumlah_produk');
        $this->db->from('pengiriman');
        $this->db->join('transaksi', 'transaksi.id_transaksi=pengiriman.id_transaksi');
        $this->db->join('jumlah_produk_transaksi', 'jumlah_produk_transaksi.id_transaksi=transaksi.id_transaksi');
        $this->db->join('pelanggan', 'pelanggan.id_pelanggan=transaksi.id_pelanggan');
        $this->db->join('user', 'user.user_id=transaksi.id_user');
        $this->db->where('pengiriman.id_pengiriman', $id);
        return $this->db->get()->result();
    }

    public function selesaikan($data, $id){
        $this->db->where('id_transaksi', $id);
        $this->db->update('pengiriman', $data);
    }
}
