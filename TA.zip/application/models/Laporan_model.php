<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Laporan_model extends CI_Model
{

    public function get_laporan()
    {
        $this->db->from('laporan');
        $this->db->order_by('tgl_laporan', 'ASC');
        return $this->db->get()->result();
    }

    public function get_laporan_detail($tgl)
    {
        $this->db->from('laporan');
        $this->db->where('tgl_laporan', $tgl);
        $this->db->order_by('tgl_laporan', 'ASC');
        return $this->db->get()->result();
    }

    public function get_laporan_detail_all()
    {
        $this->db->from('laporan');
        $this->db->order_by('tgl_laporan', 'ASC');
        return $this->db->get()->result();
    }

    public function get_bulan_laporan()
    {
        $this->db->select('MONTH(tgl_laporan) as bulan');
        $this->db->distinct();
        $this->db->from('laporan');
        $this->db->order_by('bulan', 'ASC');
        return $this->db->get()->result();
    }

    public function get_tahun_laporan()
    {
        $this->db->select('YEAR(tgl_laporan) as tahun');
        $this->db->distinct();
        $this->db->from('laporan');
        $this->db->order_by('tahun', 'ASC');
        return $this->db->get()->result();
    }

    public function get_transaksi($tgl)
    {
        $this->db->select('*');
        $this->db->select('id_transaksi, COUNT(id_transaksi) as jumlah_transaksi');
        $this->db->select('SUM(grand_total) as total_transaksi');
        $this->db->from('transaksi');
        $this->db->join('user', 'user.user_id=transaksi.id_user');
        $this->db->where('DATE_FORMAT(tgl_transaksi, "%Y-%m-%d") =', $tgl);
        return $this->db->get()->result();
    }

    public function get_transaksi_detail($tgl)
    {
        $this->db->select('*');
        $this->db->from('transaksi');
        $this->db->join('pelanggan', 'pelanggan.id_pelanggan=transaksi.id_pelanggan');
        $this->db->join('user', 'user.user_id=transaksi.id_user');
        $this->db->where('DATE_FORMAT(tgl_transaksi, "%Y-%m-%d") =', $tgl);
        return $this->db->get()->result();
    }

    public function get_transaksi_all()
    {
        $this->db->select('*');
        $this->db->select('id_transaksi, COUNT(id_transaksi) as jumlah_transaksi');
        $this->db->select('SUM(total_belanja) as total_bealanja');
        $this->db->select('SUM(diskon) as total_diskon');
        $this->db->select('SUM(grand_total) as total_transaksi');
        $this->db->select('SUM(bayar) as total_bayar');
        $this->db->select('SUM(kembalian) as total_kembalian');
        $this->db->from('transaksi');
        $this->db->join('user', 'user.user_id=transaksi.id_user');
        return $this->db->get()->result();
    }
}
