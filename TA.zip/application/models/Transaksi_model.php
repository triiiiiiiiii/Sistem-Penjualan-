<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Transaksi_model extends CI_Model
{


    public function get_transaksi()
    {
        $this->db->select('*');
        $this->db->from('transaksi');
        $this->db->join('pelanggan', 'pelanggan.id_pelanggan=transaksi.id_pelanggan');
        $this->db->join('user', 'user.user_id=transaksi.id_user');
        return $this->db->get()->result();
    }

    public function get_laporan($tgl_laporan)
    {
        $this->db->from('laporan');
        $this->db->where('tgl_laporan', $tgl_laporan);
        return $this->db->get()->result();
    }

    public function transaksi_detail($id)
    {
        $this->db->select('*');
        $this->db->select('COUNT(id_jumlah_produk) as jumlah_produk');
        $this->db->from('transaksi');
        $this->db->join('jumlah_produk_transaksi', 'jumlah_produk_transaksi.id_transaksi=transaksi.id_transaksi');
        $this->db->join('pelanggan', 'pelanggan.id_pelanggan=transaksi.id_pelanggan');
        $this->db->join('user', 'user.user_id=transaksi.id_user');
        $this->db->where('transaksi.id_transaksi', $id);
        return $this->db->get()->result();
    }

    public function transaksi_detail_jp($id)
    {
        $this->db->select('*');
        $this->db->from('jumlah_produk_transaksi');
        $this->db->join('produk', 'produk.id_produk = jumlah_produk_transaksi.id_produk');
        $this->db->where('id_transaksi', $id);
        return $this->db->get()->result();
    }

    public function get_produk()
    {
        $query = $this->db->get('produk');
        return $query->result();
    }

    public function get_pelanggan()
    {
        $this->db->select('*');
        $this->db->from('pelanggan');
        $this->db->where('status', 'aktif');
        return $this->db->get()->result();
    }

    public function get_keranjang()
    {
        $this->db->select('*');
        $this->db->from('keranjang');
        $this->db->join('produk', 'produk.id_produk=keranjang.id_produk');
        return $this->db->get()->result();
    }

    public function keranjang_add($data)
    {
        $this->db->insert('keranjang', $data);
    }

    public function transaksi_tambah($data)
    {
        $this->db->insert('transaksi', $data);
    }

    public function laporan_tambah($data)
    {
        $this->db->insert('laporan', $data);
    }

    public function kirim($data)
    {
        $this->db->insert('pengiriman', $data);
    }

    public function jumlah_produk_tambah($data)
    {
        $this->db->insert('jumlah_produk_transaksi', $data);
    }

    public function keranjang_hapus($id)
    {
        $this->db->where('id_keranjang', $id);
        $this->db->delete('keranjang');
    }

    public function hapus_keranjang_transaksi($id)
    {
        $this->db->where('id_keranjang', $id);
        $this->db->delete('keranjang');
    }

    public function update_transaksi($data, $id)
    {
        $this->db->where('id_transaksi', $id);
        $this->db->update('transaksi', $data);
    }

    public function total_belanja_keranjang()
    {
        $this->db->select('SUM(total_harga) as total_belanja');
        $this->db->from('keranjang');
        return $this->db->get()->result();
    }
}
