<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class CustomerModel extends CI_Model {


    public function get_all_customers() {
        // Ambil semua data pelanggan dari database
        $query = $this->db->get('pelanggan');
        return $query->result();
    }

    public function save_customer($data) {
        // Simpan data pelanggan ke dalam database
        $this->db->insert('pelanggan', $data);
        return $this->db->insert_id();
    }

    function edit_data($where, $table)
    {
        return $this->db->get_where($table, $where);
    }

    function get_data($table)
    {
        return $this->db->get($table);
    }

    function insert_data($data, $table)
    {
        $this->db->insert($table, $data);
    }
    function update_data($where, $data, $table)
    {
        $this->db->where($where);
        $this->db->update($table, $data);
    }
    function delete_data($where, $table)
    {
        $this->db->where($where);
        $this->db->delete($table);
    }

    
}
