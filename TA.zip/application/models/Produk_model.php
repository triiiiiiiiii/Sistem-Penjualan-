<?php
class Produk_model extends CI_Model
{
    function get_data($table)
    {
        return $this->db->get($table);
    }

    public function getAllData() {
        $this->db->select('*');
        $this->db->from('produk_masuk');
        $this->db->join('user','user.user_id=produk_masuk.user_id');
        $this->db->join('produk','produk.id_produk=produk_masuk.id_produk');
        return $this->db->get()->result();
    }

    public function get_produk_edit($id)
    {
        $this->db->select('*');
        $this->db->from('produk');
        $this->db->where('id_produk', $id);
        return $this->db->get()->result();
    }

    public function get_produk()
    {
        $query = $this->db->get('produk');
        return $query->result();
    }

    public function get_produk_update()
    {
        $query = $this->db->get('produk');
        return $query->result();
    }

    public function edit_stok($id)
    {
        $this->db->select('*');
        $this->db->from('produk');
        $this->db->where('id_produk', $id);
        return $this->db->get()->result();
    }

    public function produk_add($data)
    {
        $this->db->insert('produk', $data);
        return $this->db->insert_id();
    }

    public function delete_produk($id)
    {
        $this->db->where('id_produk', $id);
        $this->db->delete('produk');
    }

    public function add_stock_in($data)
    {
        $this->db->insert('produk_masuk', $data);
    }

    function update_stock($update_stok, $id)
    {
        $this->db->where('id_produk', $id);
        $this->db->update('produk', $update_stok);
    }

    public function produk_edit($data, $id)
    {
        $this->db->where('id_produk', $id);
        $this->db->update('produk', $data);
    }


}
