<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pelanggan_model extends CI_Model {


    public function get_all_pelanggan() {
        // Ambil semua data pelanggan dari database
        $query = $this->db->get('pelanggan');
        return $query->result();
    }

    public function get_pelanggan_edit($id)
    {
        $this->db->select('*');
        $this->db->from('pelanggan');
        $this->db->where('id_pelanggan', $id);
        return $this->db->get()->result();
    }

    function pelanggan_add($data)
    {
        $this->db->insert('pelanggan', $data);
    }

    function pelanggan_edit($data, $id)
    {
        $this->db->where('id_pelanggan', $id);
        $this->db->update('pelanggan', $data);
    }

    function pelanggan_hapus($id)
    {
        $this->db->where('id_pelanggan', $id);
        $this->db->delete('pelanggan');
    }

    public function pelanggan_jumlah()
    {
        $this->db->select('COUNT(id_pelanggan) as jumlah_pelanggan');
        $this->db->from('pelanggan');
        return $this->db->get()->result();
    }
    
}
 