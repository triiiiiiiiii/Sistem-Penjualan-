<?php
defined('BASEPATH') or exit('No direct script access allowed');

class User extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        if ($this->session->userdata('logged') != TRUE) {
            $url = base_url('welcome/halamanlogin');
            redirect($url);
        };
        $this->load->model('UserModel');
    }

    public function index()
    {
        $data['user'] = $this->UserModel->get_user();
        $this->load->view('template/header', $data);
        $this->load->view('template/sidebar');
        $this->load->view('user/user_list', $data);
        $this->load->view('template/footer');
    }

    public function user_add()
    {
        $this->load->view('template/header');
        $this->load->view('template/sidebar');
        $this->load->view('user/user_add');
        $this->load->view('template/footer');
    }

    function user_add_act()
    {
        $nama = $this->input->post('nama');
        $email = $this->input->post('email');
        $password = $this->input->post('password');
        $role = $this->input->post('role');
        $status = $this->input->post('status');

        $hashed_password = hash('sha224', $password);

        $data = array(
            'user_name' => $nama,
            'user_email' => $email,
            'user_password' => $hashed_password,
            'user_akses' => $role,
            'user_status' => $status
        );

        $this->UserModel->user_add($data);
        $this->session->set_flashdata('success', 'User berhasil ditambahkan');
        redirect('user');
    }

    public function user_edit($id)
    {
        $data['user'] = $this->UserModel->get_user_edit($id);
        $this->load->view('template/header', $data);
        $this->load->view('template/sidebar');
        $this->load->view('user/user_edit', $data);
        $this->load->view('template/footer');
    }

    function user_edit_act()
    {
        $id = $this->input->post('user_id');
        $nama = $this->input->post('nama');
        $email = $this->input->post('email');
        $password = $this->input->post('password');
        $role = $this->input->post('role');
        $status = $this->input->post('status');

        if (empty($password)) {
            $data = array(
                'user_name' => $nama,
                'user_email' => $email,
                'user_akses' => $role,
                'user_status' => $status
            );
        } else {
            $data = array(
                'user_name' => $nama,
                'user_email' => $email,
                'user_password' => SHA1($password),
                'user_akses' => $role,
                'user_status' => $status
            );
        }

        $this->UserModel->user_edit_act($data, $id);
        $this->session->set_flashdata('success', 'User berhasil diedit');
        redirect('user');
    }

    function user_hapus($id)
    {
        $this->UserModel->user_hapus($id);
        $this->session->set_flashdata('success', 'user berhasil dihapus');
        redirect('user');
    }
}
