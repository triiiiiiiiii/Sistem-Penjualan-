<?php
class Produk_masuk extends CI_Controller {
    public function __construct() {
        parent::__construct();
        if($this->session->userdata('logged') !=TRUE){
            $url = base_url('welcome/halamanlogin');
            redirect($url);
		};
        $this->load->model('Produk_model');
    }

    public function index() {
        // Retrieve data and load view
        $data['produk_masuk'] = $this->Produk_model->getAllData();
        $this->load->view('template/header', $data);
        $this->load->view('template/sidebar');
        $this->load->view('produk/produk_masuk_list', $data);
        $this->load->view('template/footer');
         
    }

    public function tambah($id)
    {
        $data['produk'] = $this->Produk_model->edit_stok($id);
        $this->load->view('template/header', $data);
        $this->load->view('template/sidebar');
        $this->load->view('produk/add_stock_form', $data);
        $this->load->view('template/footer');
    }


    public function tambah_stok() 
    {
        $id =  $this->input->post('id_produk');
        $stok_masuk =  $this->input->post('stok_masuk');
        $tgl_masuk =  $this->input->post('tgl_masuk');

        $data = array(
            'id_produk' => $id,
            'stok_masuk' => $stok_masuk,
            'tanggal_masuk' => $tgl_masuk,
            'user_id' => $this->session->userdata('id'),
        );

        $this->db->query("UPDATE produk SET stok = stok +'$stok_masuk' WHERE id_produk='$id' ");
        $this->Produk_model->add_stock_in($data);
        $this->session->set_flashdata('success', 'Stok berhasil ditambahkan');
        redirect('produk');
    } 



    
}
