<?php
class Produk extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        if($this->session->userdata('logged') !=TRUE){
            $url = base_url('welcome/halamanlogin');
            redirect($url);
		};
        $this->load->model('Produk_model');
    }

    public function index()
    {
        $data['produk'] = $this->Produk_model->get_produk();
        $this->load->view('template/header', $data);
        $this->load->view('template/sidebar');
        $this->load->view('produk/produk_list', $data);
        $this->load->view('template/footer');
    }

    public function produk_add()
    {
        $this->load->view('template/header');
        $this->load->view('template/sidebar');
        $this->load->view('produk/produk_add');
        $this->load->view('template/footer');
    }

    public function produk_edit($id)
    {
        $data['produk'] = $this->Produk_model->get_produk_edit($id);
        $this->load->view('template/header', $data);
        $this->load->view('template/sidebar');
        $this->load->view('produk/produk_edit', $data);
        $this->load->view('template/footer');
    }

    public function produk_add_act()
    {
        $produk_data = array(
            'nama' => $this->input->post('nama'),
            'stok' => $this->input->post('stok'),
            'harga' => $this->input->post('harga')
        );

        $this->Produk_model->produk_add($produk_data);
        $this->session->set_flashdata('success', 'Produk berhasil ditambahkan');
        redirect('produk');
    }

    public function produk_edit_act()
    {
        $id = $this->input->post('id_produk');

        $produk_data = array(
            'nama' => $this->input->post('nama'),
            'harga' => $this->input->post('harga')
        );

        $this->Produk_model->produk_edit($produk_data, $id);
        $this->session->set_flashdata('success', 'Produk berhasil diedit');
        redirect('produk');
    }

    public function delete($id)
    {
        $this->Produk_model->delete_produk($id);
        $this->session->set_flashdata('success', 'Produk berhasil dihapus');
        redirect('produk');
    }
}
