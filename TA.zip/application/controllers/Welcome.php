<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Welcome extends CI_Controller
{


	public function index()
	{
		$this->load->view('index.php');
	}

	public function halamanlogin()
	{
		if ($this->session->userdata('logged') == TRUE) {
			$url = base_url('dashboard');
			redirect($url);
		} else {
			$this->load->view('view-login.php');
		}
	}
}
