<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Dashboard extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        if ($this->session->userdata('logged') != TRUE) {
            $url = base_url('Welcome/halamanlogin');
            redirect($url);
        };
        $this->load->model('Dashboard_model');
    }

    public function index()
    {
        $data['pelanggan'] = $this->Dashboard_model->pelanggan_jumlah();
        $data['produk'] = $this->Dashboard_model->produk_jumlah();
        $data['transaksi'] = $this->Dashboard_model->transaksi_jumlah();
        $data['transaksi_total'] = $this->Dashboard_model->transaksi_jumlah_total();
        $this->load->view('template/header');
        $this->load->view('template/sidebar');
        $this->load->view('dashboard', $data);
        $this->load->view('template/footer');
    }

}
