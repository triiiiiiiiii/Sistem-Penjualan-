<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Laporan extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        if ($this->session->userdata('logged') != TRUE) {
            $url = base_url('Welcome/halamanlogin');
            redirect($url);
        };
        $this->load->model('Laporan_model');
        $this->load->model('Transaksi_model');
        $this->load->model('Produk_model');
    }

    public function laporan_transaksi()
    {
        $data['laporan'] = $this->Laporan_model->get_laporan();
        $data['bulan'] = $this->Laporan_model->get_bulan_laporan();
        $data['tahun'] = $this->Laporan_model->get_tahun_laporan();
        $this->load->view('template/header', $data);
        $this->load->view('template/sidebar');
        $this->load->view('laporan_transaksi/laporan_list', $data);
        $this->load->view('template/footer');
    }

    public function laporan_detail($tgl)
    {
        $data['laporan'] = $this->Laporan_model->get_laporan_detail($tgl);
        $data['transaksi'] = $this->Laporan_model->get_transaksi($tgl);
        $data['transaksi_detail'] = $this->Laporan_model->get_transaksi_detail($tgl);
        $this->load->view('template/header', $data);
        $this->load->view('template/sidebar');
        $this->load->view('laporan_transaksi/laporan_detail', $data);
        $this->load->view('template/footer');
    }

    public function laporan_per_hari()
    {
        $data['laporan'] = $this->Laporan_model->get_laporan();
        $data['transaksi'] = $this->Laporan_model->get_transaksi_all();
        $this->load->view('laporan_transaksi/laporan_per_hari', $data);
    }

    public function laporan_per_transaksi()
    {
        $data['transaksi_all'] = $this->Laporan_model->get_transaksi_all();
        $data['transaksi'] = $this->Transaksi_model->get_transaksi();
        $this->load->view('laporan_transaksi/laporan_per_transaksi', $data);
    }

    public function laporan_produk_masuk() {
        // Retrieve data and load view
        $data['produk_masuk'] = $this->Produk_model->getAllData();
        $this->load->view('template/header', $data);
        $this->load->view('template/sidebar');
        $this->load->view('produk/produk_masuk_list', $data);
        $this->load->view('template/footer');
         
    }

    public function laporan_produk_masuk_print() {
        // Retrieve data and load view
        $data['produk_masuk'] = $this->Produk_model->getAllData();
        $this->load->view('produk/laporan_produk_masuk_print', $data);
         
    }
}
