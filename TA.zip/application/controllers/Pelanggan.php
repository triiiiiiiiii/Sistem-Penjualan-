<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Pelanggan extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        if ($this->session->userdata('logged') != TRUE) {
            $url = base_url('welcome/halamanlogin');
            redirect($url);
        };
        $this->load->model('Pelanggan_model');
    }

    public function index()
    {
        $data['pelanggan'] = $this->Pelanggan_model->get_all_pelanggan();
        $this->load->view('template/header', $data);
        $this->load->view('template/sidebar');
        $this->load->view('pelanggan/pelanggan_list', $data);
        $this->load->view('template/footer');
    }

    public function pelanggan_add()
    {
        $this->load->view('template/header');
        $this->load->view('template/sidebar');
        $this->load->view('pelanggan/pelanggan_add');
        $this->load->view('template/footer');
    }

    public function pelanggan_edit($id)
    {
        $data['pelanggan'] = $this->Pelanggan_model->get_pelanggan_edit($id);
        $this->load->view('template/header', $data);
        $this->load->view('template/sidebar');
        $this->load->view('pelanggan/pelanggan_edit', $data);
        $this->load->view('template/footer');
    }

    function pelanggan_add_act()
    {
        $nama = $this->input->post('nama');
        $email = $this->input->post('email');
        $telefon = $this->input->post('telefon');
        $alamat = $this->input->post('alamat');
        $status = $this->input->post('status');

        $data = array(
            'nama' => $nama,
            'email' => $email,
            'telefon' => $telefon,
            'alamat' => $alamat,
            'status' => $status
        );

        $this->Pelanggan_model->pelanggan_add($data);
        $this->session->set_flashdata('success', 'Pelanggan berhasil ditambahkan');
        redirect('pelanggan');
    }

    function pelanggan_edit_act()
    {
        $id = $this->input->post('id_pelanggan');
        $nama = $this->input->post('nama');
        $email = $this->input->post('email');
        $telefon = $this->input->post('telefon');
        $alamat = $this->input->post('alamat');
        $status = $this->input->post('status');

        $data = array(
            'nama' => $nama,
            'email' => $email,
            'telefon' => $telefon,
            'alamat' => $alamat,
            'status' => $status
        );
        $this->Pelanggan_model->pelanggan_edit($data, $id);
        $this->session->set_flashdata('success', 'Pelanggan berhasil diedit');
        redirect('pelanggan');
    }
    
    function pelanggan_hapus($id)
    {
        $this->Pelanggan_model->pelanggan_hapus($id);
        $this->session->set_flashdata('success', 'Pelanggan berhasil dihapus');
        redirect('pelanggan');
    }
}
