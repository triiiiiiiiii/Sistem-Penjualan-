<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Transaksi extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        if ($this->session->userdata('logged') != TRUE) {
            $url = base_url('welcome/halamanlogin');
            redirect($url);
        };
        $this->load->model('Transaksi_model');
    }

    public function index()
    {
        $data['transaksi'] = $this->Transaksi_model->get_transaksi();
        $this->load->view('template/header', $data);
        $this->load->view('template/sidebar');
        $this->load->view('transaksi/transaksi_list', $data);
        $this->load->view('template/footer');
    }

    public function transaksi_add()
    {
        $data['produk'] = $this->Transaksi_model->get_produk();
        $data['pelanggan'] = $this->Transaksi_model->get_pelanggan();
        $data['keranjang'] = $this->Transaksi_model->get_keranjang();
        $data['total_belanja'] = $this->Transaksi_model->total_belanja_keranjang();
        $this->load->view('template/header', $data);
        $this->load->view('template/sidebar');
        $this->load->view('transaksi/transaksi_add', $data);
        $this->load->view('template/footer');
    }

    public function keranjang_add_act()
    {
        $id_produk = $this->input->post('id_produk');
        $harga = $this->input->post('harga');
        $stok = $this->input->post('stok');
        $qty = $this->input->post('qty');

        $data = array(
            'id_produk' => $id_produk,
            'qty' => $qty,
            'harga' => $harga,
            'total_harga' => $harga * $qty,
        );

        if ($qty > $stok) {
            $this->session->set_flashdata('failed', 'Stok tidak mencukupi');
            redirect('transaksi/transaksi_add');
        } else {
            $this->db->query("UPDATE produk SET stok = stok -'$qty' WHERE id_produk='$id_produk' ");

            $this->Transaksi_model->keranjang_add($data);
            redirect('transaksi/transaksi_add');
        }
    }

    public function keranjang_hapus()
    {
        $id = $this->input->post('id_keranjang');
        $id_produk = $this->input->post('id_produk');
        $qty = $this->input->post('qty');

        $this->db->query("UPDATE produk SET stok = stok +'$qty' WHERE id_produk='$id_produk' ");

        $this->Transaksi_model->keranjang_hapus($id);
        redirect('transaksi/transaksi_add');
    }

    public function transaksi_add_act()
    {
        $tanggal = $this->input->post('tanggal');
        $tgl_laporan = date('Y-m-d', strtotime($tanggal));
        $laporan = $this->Transaksi_model->get_laporan($tgl_laporan);
        $staff = $this->input->post('staff');
        $pelanggan = $this->input->post('pelanggan');
        $total_belanja = $this->input->post('total_belanja');
        $diskon = $this->input->post('diskon');
        $grand_total = $this->input->post('grand_total');
        $bayar = $this->input->post('bayar');
        $kembalian = $this->input->post('kembalian');
        $transaksi_data = array(
            'tgl_transaksi' => $tanggal,
            'id_user' => $staff,
            'id_pelanggan' => $pelanggan,
            'total_belanja' => $total_belanja,
            'diskon' => $diskon,
            'grand_total' => $grand_total,
            'bayar' => $bayar,
            'kembalian' => $kembalian,
        );

        $laporan_data = array(
            'tgl_laporan' => $tgl_laporan,
        );

        foreach ($laporan as $l) {
            $laporan_tgl = $l->tgl_laporan;
        }

        if ($tgl_laporan != $laporan_tgl) {
            $this->Transaksi_model->laporan_tambah($laporan_data);
        }
        $this->Transaksi_model->transaksi_tambah($transaksi_data);

        $id_transaksi = $this->db->insert_id();

        // Ambil data dari form
        $id_keranjang = $this->input->post('id_keranjang');
        $id_produk = $this->input->post('id_produk');
        $qty = $this->input->post('qty');
        $harga = $this->input->post('harga');
        $total_harga = $this->input->post('total_harga');

        // Loop melalui data yang diterima
        for ($i = 0; $i < count($id_produk); $i++) {
            $jumlah_produk_data = array(
                'id_transaksi' => $id_transaksi,
                'id_produk' => $id_produk[$i],
                'qty' => $qty[$i],
                'harga' => $harga[$i],
                'total_harga' => $total_harga[$i]
            );

            $id_keranjang1 = $id_keranjang[$i];


            $this->Transaksi_model->hapus_keranjang_transaksi($id_keranjang1);

            // Simpan data ke tabel jumlah_produk
            $this->Transaksi_model->jumlah_produk_tambah($jumlah_produk_data);
        }
        $this->session->set_flashdata('success', 'Transaksi berhasil ditambahkan');
        redirect('transaksi');
    }

    public function transaksi_detail($id)
    {
        $data['transaksi_detail'] = $this->Transaksi_model->transaksi_detail($id);
        $data['jumlah_produk'] = $this->Transaksi_model->transaksi_detail_jp($id);
        $this->load->view('template/header', $data);
        $this->load->view('template/sidebar');
        $this->load->view('transaksi/transaksi_detail', $data);
        $this->load->view('template/footer');
    }

    public function kirim($id)
    {
        $data = array(
            'tgl_kirim' => date('Y-m-d H:i:s'),
            'id_transaksi' => $id,
        );

        $data_2 = array(
            'status_pengiriman' => 1,
        );

        $this->Transaksi_model->update_transaksi($data_2, $id);
        $this->Transaksi_model->kirim($data);
        $this->session->set_flashdata('success', 'Produk berhasil dikirim');
        redirect('transaksi');
    }
}
