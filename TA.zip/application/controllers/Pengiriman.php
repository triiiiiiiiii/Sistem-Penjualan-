<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Pengiriman extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        if ($this->session->userdata('logged') != TRUE) {
            $url = base_url('welcome/halamanlogin');
            redirect($url);
        };
        $this->load->model('Transaksi_model');
        $this->load->model('Pengiriman_model');
    }

    public function index()
    {
        $data['pengiriman'] = $this->Pengiriman_model->get_pengiriman();
        $this->load->view('template/header', $data);
        $this->load->view('template/sidebar');
        $this->load->view('pengiriman/pengiriman_list', $data);
        $this->load->view('template/footer');
    }

    public function keranjang_hapus()
    {
        $id = $this->input->post('id_keranjang');
        $id_produk = $this->input->post('id_produk');
        $qty = $this->input->post('qty');

        $this->db->query("UPDATE produk SET stok = stok +'$qty' WHERE id_produk='$id_produk' ");

        $this->Transaksi_model->keranjang_hapus($id);
        redirect('transaksi/transaksi_add');
    }

    public function pengiriman_detail($id)
    {
        $data['pengiriman_detail'] = $this->Pengiriman_model->pengiriman_detail($id);
        $data['jumlah_produk'] = $this->Transaksi_model->transaksi_detail_jp($id);
        $this->load->view('template/header', $data);
        $this->load->view('template/sidebar');
        $this->load->view('pengiriman/pengiriman_detail', $data);
        $this->load->view('template/footer');
    }

    public function selesaikan($id)
    {
        $data = array(
            'tgl_sampai' => date('Y-m-d H:i:s'),
        );

        $data_2 = array(
            'status_pengiriman' => 2,
        );

        $this->Transaksi_model->update_transaksi($data_2, $id);
        $this->Pengiriman_model->selesaikan($data, $id);
        $this->session->set_flashdata('success', 'Pengiriman telah selesai');
        redirect('pengiriman');
    }
}
