<!DOCTYPE html>
<html>
<head>
    <title>Toko Online Intip Kendil Emas</title>
    <link rel="stylesheet" href="styles.css">
    <link href="assets/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
</head>
<body>
    <!-- Header Section -->
    <header class="fixed-header">
        <div class="logo">Toko Intip Kendil Mas</div>
        <nav>
            <ul>
                <li><a href="#">Home</a></li>
                <li><a href="#produk">Products</a></li>
                <li><a href="#">About Us</a></li>
                <li><a href="#kontak">Contact</a></li>
            </ul>
        </nav>
        <div class="cta-buttons">
            
            <a href="<?php echo base_url('welcome/halamanlogin');?>" class="cta-login">Log In</a>
        </div>
    </header>

    <!-- Hero Section -->
    <section class="hero">
        <div class="hero-content">
            <h1>Cari Oleh-Oleh dari Solo, INTIP-in Aja</h1>
            <p>Makanan ringan berbahan alami dengan harga yang pas di hati</p>
            
            
        </div>
        
    </section>
    <section class="judul">produk yang dijual</section>
    </section> 

    <!-- Products/Services Section -->
    <div class="row">
        
    <section class="products" id="produk">
        <div class="product">
            <img src="image/produk 1.jpeg" alt="Product 1">
            <h2>Intip Madu</h2>
            <p>Produk unggulan dari kami, bukan tentang sebesar apa namun ini soal rasa</p>
            <br><p style="color: red;">Harga: Rp.8.500,-</p>
            
        </div>
        <div class="product">
            <img src="image/produk 3.jpg" alt="Product 2">
            <h2>Intip Besar Asin</h2>
            <p>Sangat Rekomendasi buat kalian yang suka dengan rasa asin </p>
            <br><p style="color: red;">Harga: Rp.7.500,-</p>
           
        </div>
        <div class="col">
        <div class="product">
            <img src="image/produk 2.jpeg" alt="Product 3">
            <h2>Intip Besar Manis</h2>
            <p>Rekomendasi buat kalian yang suka dengan manis-manis</p>
            <br><p style="color: red;">Harga: Rp.7.500,-</p>
        </div>
        </div>
           
        <div class="product">
            <img src="image/produk 4.jpg" alt="Product 4">
            <h2>Intip Madu Asin</h2>
            <p>Rekomendasi buat pecinta rasa asin dengan ukuran kecil</p>
            <br><p style="color: red;">Harga: Rp.7.000,-</p>
            
        </div>
        <!-- Add more products as needed -->
    </section>
    </div>
        </div>

     <!-- Call-to-Action Section -->
     <section class="cta-section" id="">
        <h2>Apakah Anda Tertarik?</h2>
        <a href="https://api.whatsapp.com/send?phone=+6288233517274&text=Hai, saya tertarik dengan produk Anda, Apakah Masih Tersedia?" class="cta-big fa fa-phone"> Hub Via Whatsapp</a>
    </section>



   

    <!-- Footer Section -->
    <footer id="kontak">
        <p>&copy; 2023 CV. Intip Kendil Emas. No. Telp (088233517274)</p>
        <nav>
            <ul>
            <li><a href="#">intipkendilemas@gmail.com</a></li>
            </ul>
            <ul>
            <li><a href="#">Sumberlawang, Sragen</a></li>
            </ul>
        </nav>
    </footer>
</body>
</html>