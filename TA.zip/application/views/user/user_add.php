
<div class="container-fluid">

    <!-- Page Heading -->
    <!--
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">User Add</h1>
    </div>
    <div class="card">

        <form method="post" action="<?php echo base_url('user/user_add_act'); ?>">
            <div class="card-body">
                <div class="form-group">
                    <label for="nama" class="col-form-label">Nama User</label>
                    <input type="text" class="form-control" name="nama" id="nama" placeholder="masukkan nama user.." required>
                </div>
                <div class="form-group">
                    <label for="email" class="col-form-label">E-mail</label>
                    <input type="email" class="form-control" name="email" id="email" placeholder="masukkan email.." required>
                </div>
                <div class="form-group">
                    <label for="password" class="col-form-label">Password</label>
                    <input type="password" class="form-control" name="password" id="password" placeholder="masukkan password.." required>
                </div>
                <div class="form-group">
                    <label for="role" class="col-form-label">Role</label>
                    <select class="form-control" id="role" name="role" required>
                        <option value="">-- Pilih --</option>
                        <option value="1">Admin</option>
                        <option value="2">Staff</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="status" class="col-form-label">Status</label>
                    <select class="form-control" id="status" name="status" required>
                        <option value="">-- Pilih --</option>
                        <option value="1">Aktif</option>
                        <option value="2">Nonaktif</option>
                    </select>
                </div>
            </div>
            <div class="card-footer">
                <button type="reset" class="btn btn-secondary">Reset</button>
                <button type="submit" class="btn btn-primary"><i class="fa fa-save"></i> Simpan</button>
            </div>
        </form>
    </div> -->

     
    <div class="container">
    <div class="row"> 
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title mb-4">Tambah User</h4>
                    <form action="<?php echo base_url('user/user_add_act'); ?>" method="post">

                    <div class="form-body">
                            <div class="form-group">
                                <div class="row">
                                    <label class="col-lg-2">Username</label>
                                    <div class="col-lg-10">
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="input-group">
                                                    <div class="input-group-prepend">
                                                        <label class="input-group-text" for="inputGroupSelect01"><i class="fas fa-user"></i></label>
                                                    </div>
                                                    <input type="text" class="form-control" name="nama" id="nama" placeholder="masukkan nama user.." required>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="row">
                                    <label class="col-lg-2">E-mail</label>
                                    <div class="col-lg-10">
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="input-group">
                                                    <div class="input-group-prepend">
                                                        <label class="input-group-text" for="inputGroupSelect01"><i class="fas fa-at"></i></label>
                                                    </div>
                                                    <input type="email" class="form-control" name="email" id="email" placeholder="masukkan email.." required>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="row">
                                    <label class="col-lg-2">Password</label>
                                    <div class="col-lg-10">
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="input-group">
                                                    <div class="input-group-prepend">
                                                        <label class="input-group-text" for="inputGroupSelect01"><i class="fas fa-key"></i></label>
                                                    </div>
                                                    <input type="password" class="form-control" name="password" id="password" placeholder="masukkan password.." required>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div><div class="form-group">
                                <div class="row">
                                    <label class="col-lg-2">Akses</label>
                                    <div class="col-lg-10">
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="input-group">
                                                    <div class="input-group-prepend">
                                                        <label class="input-group-text" for="inputGroupSelect01"><i class="fas fa-address-card"></i></label>
                                                    </div>
                                                    <select class="form-control" id="role" name="role" required>
                                                        <option value="">-- Pilih --</option>
                                                        <option value="1">Admin</option>
                                                        <option value="2">Staff</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            </div><div class="form-group">
                                <div class="row">
                                    <label class="col-lg-2">Status</label>
                                    <div class="col-lg-10">
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="input-group">
                                                    <div class="input-group-prepend">
                                                        <label class="input-group-text" for="inputGroupSelect01"><i class="fas fa-address-card"></i></label>
                                                    </div>
                                                    <select class="form-control" id="status" name="status" required>
                                                        <option value="">-- Pilih --</option>
                                                        <option value="1">Aktif</option>
                                                        <option value="2">Nonaktif</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="form-actions">
                            <div class="text-right">
                                <button type="submit" class="btn btn-primary">Submit</button>
                                <button type="reset" class="btn btn-secondary">Reset</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div> <b><br><br></b>


           
