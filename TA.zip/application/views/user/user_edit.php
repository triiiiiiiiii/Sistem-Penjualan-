<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">User Add</h1>
    </div>
    <div class="card">
        <form method="post" action="<?php echo base_url('user/user_edit_act'); ?>">
            <?php foreach ($user as $u) { ?>
                <div class="card-body">
                    <div class="form-group">
                        <label for="nama" class="col-form-label">Nama User</label>
                        <input type="hidden" name="user_id" value="<?= $u->user_id ?>">
                        <input type="text" class="form-control" name="nama" id="nama" value="<?= $u->user_name ?>" placeholder="masukkan nama user.." required>
                    </div>
                    <div class="form-group">
                        <label for="email" class="col-form-label">E-mail</label>
                        <input type="email" class="form-control" name="email" id="email" value="<?= $u->user_email ?>" placeholder="masukkan email.." required>
                    </div>
                    <div class="form-group">
                        <label for="password" class="col-form-label">Password</label>
                        <input type="password" class="form-control" name="password" id="password" placeholder="masukkan password..">
                        <small class="text-danger">isi jika ingin mengubah password</small>
                    </div>
                    <div class="form-group">
                        <label for="role" class="col-form-label">Role</label>
                        <select class="form-control" id="role" name="role" required>
                            <option value="">-- Pilih --</option>
                            <?php if ($u->user_akses == 1) { ?>
                                <option value="1" selected>Admin</option>
                                <option value="2">Staff</option>
                            <?php } else { ?>
                                <option value="1">Admin</option>
                                <option value="2" selected>Staff</option>
                            <?php } ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="status" class="col-form-label">Status</label>
                        <select class="form-control" id="status" name="status" required>
                        <option value="">-- Pilih --</option>
                            <?php if ($u->user_status == 1) { ?>
                                <option value="1" selected>Aktif</option>
                                <option value="2">Nonaktif</option>
                            <?php } else { ?>
                                <option value="1">Aktif</option>
                                <option value="2" selected>Nonaktif</option>
                            <?php } ?>
                        </select>
                    </div>
                </div>
                <div class="card-footer">
                    <button type="reset" class="btn btn-secondary">Reset</button>
                    <button type="submit" class="btn btn-primary"><i class="fa fa-save"></i> Simpan</button>
                </div>
            <?php } ?>
        </form>
    </div>