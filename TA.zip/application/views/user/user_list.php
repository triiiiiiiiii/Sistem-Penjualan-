 <!-- Begin Page Content -->
 <div class="container-fluid">

     <!-- Page Heading -->
     <div class="d-sm-flex align-items-center justify-content-between mb-4">
         <h1 class="h3 mb-0 text-gray-800">User List</h1>
     </div>

     <div class="card">
         <div class="card-header">
             <a class="btn btn-primary btn-sm" href="<?= site_url('user/user_add'); ?>"><i class="fa fa-user-plus"></i> User Baru</a>
         </div>
         <div class="card-body">
             <table class="table table-bordered" id="dataTable">
                 <thead>
                     <tr>
                         <th class="text-center" style="width: 1%;">No</th>
                         <th>Nama User</th>
                         <th>E-mail</th>
                         <th class="text-center">Role</th>
                         <th class="text-center">Status</th>
                         <th class="text-center" style="width: 15%;">Aksi</th>
                     </tr>
                 </thead>
                 <tbody>
                     <?php
                        $no = 1;
                        foreach ($user as $u) { ?>
                         <tr>
                             <td class="text-center"><?= $no++; ?></td>
                             <td><?= $u->user_name; ?></td>
                             <td><?= $u->user_email; ?></td>
                             <td class="text-center">
                                 <?php if ($u->user_akses == 1) { ?>
                                     Admin
                                 <?php } else { ?>
                                     Staff
                                 <?php } ?>
                             </td>
                             <td class="text-center">
                                 <?php if ($u->user_status == 1) { ?>
                                     <span class="badge badge-success">Aktif</span>
                                 <?php } else { ?>
                                     <span class="badge badge-danger">Nonaktif</span>
                                 <?php } ?>
                             </td>
                             <td class="text-center">
                                 <a class="btn btn-warning btn-sm" href="<?= site_url('user/user_edit/' . $u->user_id); ?>"><i class="fa fa-edit"></i> Edit</a>
                                 <a class="btn btn-danger btn-sm" href="<?= site_url('user/user_hapus/' . $u->user_id); ?>" id="alert-hapus"><i class="fa fa-trash-alt"></i> Hapus</a>
                             </td>
                         </tr>
                     <?php } ?>
                 </tbody>
             </table>
         </div>
     </div>
 </div>