<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Produk Masuk</h1>
    </div>

    <div class="card">
        <!-- <div class="card-header">
            <?php if ($this->session->userdata('access') == 'Admin') { ?>
                <a href="<?php echo base_url() . 'produk/index'; ?>" class="btn btn-primary btn-sm">Tambah Stok</a>
            <?php } ?>
        </div> -->
        <div class="card-body">


            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama Produk</th>
                        <th>Tanggal Masuk</th>
                        <th>Stok Masuk</th>
                        <th>User</th>
                        <th>Aksi</th>

                    </tr>
                </thead>
                <tbody>

                    <?php

                    $no = 1;
                    foreach ($produk_masuk as $pm) { ?>
                        <tr>
                            <td><?php echo $no++; ?></td>
                            <td><?php echo $pm->nama; ?></td>
                            <td><?php echo $pm->tanggal_masuk; ?></td>
                            <td><?php echo $pm->stok_masuk; ?></td>
                            <td><?php echo $pm->user_name; ?></td>
                            <td>

                                <button class="btn btn-success btn-sm " onclick="printDiv('printBukti')">Cetak Bukti <i class="fas fa-angle-right"></i></button>

                                <a class="btn btn-danger btn-sm" href="<?php echo base_url() . 'produk_masuk/hapus_produk_masuk/' . $pm->id_produk_masuk; ?>"><span class="glyphicon glyphicon-trash"></span> Hapus</a>
                            </td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
</div>