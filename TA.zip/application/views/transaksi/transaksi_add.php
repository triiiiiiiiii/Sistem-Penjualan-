<?php
$this->db->select('*');
$this->db->from('keranjang');
$keranjang_total = $this->db->get()->num_rows();
foreach ($total_belanja as $t) {
    $total_belanja_1 = $t->total_belanja;
}

?>
<!-- Begin Page Content -->
<div class="container-fluid">
    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Transaksi Add</h1>
    </div>

    <div class="row">
        <div class="col-md-4 mb-4">
            <div class="card">
                <div class="card-header">
                    <i class="fa fa-cart-plus"></i> Tambah Keranjang
                </div>
                <form action="<?= site_url('transaksi/keranjang_add_act') ?>" method="post">
                    <div class="card-body">
                        <div class="row">
                            <div class="form-group col-md-12 mb-1">
                                <label for="produk" class="col-form-label">Produk</label>
                                <input type="hidden" name="id_produk" id="id_produk">
                                <input type="hidden" name="harga" id="harga">
                                <input type="hidden" name="stok" id="stok">
                                <div class="input-group">
                                    <input type="text" class="form-control bg-transparent" id="nama" name="produk" placeholder="pilih produk.." readonly required>
                                    <div class="input-group-append">
                                        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#modal_produk"><i class="fa fa-search"></i></button>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group col-md-6 mb-1">
                                <label for="qty" class=" col-form-label">Qty</label>
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <button class="btn btn-danger" type="button" id="decrease">-</button>
                                    </div>
                                    <input type="text" class="form-control bg-transparent text-center" name="qty" id="quantity" value="1" required>
                                    <div class="input-group-append">
                                        <button class="btn btn-primary" type="button" id="increase">+</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card-footer">
                        <button type="submit" class="btn btn-sm btn-primary"><i class="fa fa-cart-plus"></i> Tambah</button>
                    </div>
                </form>
            </div>
        </div>
        <div class="col-md-8 mb-4">
            <div class="card" style="height: 350px;">
                <div class="card-header">
                    <div class="row">
                        <div class="col-md-6 col-6">
                            <i class="fa fa-shopping-cart"></i> Keranjang
                        </div>
                        <div class="col-md-6 col-6 text-right">
                            <?= $keranjang_total ?> Produk
                        </div>
                    </div>
                </div>
                <div class="card-body table-responsive">
                    <table class="table table-bordered table-hover" id="dataTable1">
                        <thead>
                            <th>Nama Produk</th>
                            <th>Qty</th>
                            <th>Harga</th>
                            <th>Total</th>
                            <th>Hapus</th>
                        </thead>
                        <tbody>
                            <?php $no = 1;
                            foreach ($keranjang as $k) { ?>
                                <tr>
                                    <td><?= $k->nama ?></td>
                                    <td><?= $k->qty ?></td>
                                    <td>Rp.<?= number_format($k->harga, 0, ',', '.') ?>,-</td>
                                    <td>Rp.<?= number_format($k->total_harga, 0, ',', '.') ?>,-</td>
                                    <td>
                                        <form action="<?= site_url('transaksi/keranjang_hapus') ?>" method="post">
                                            <input type="hidden" name="id_keranjang" value="<?= $k->id_keranjang ?>">
                                            <input type="hidden" name="id_produk" value="<?= $k->id_produk ?>">
                                            <input type="hidden" name="qty" value="<?= $k->qty ?>">
                                            <button type="submit" class="btn btn-sm btn-danger">
                                                <i class="fa fa-trash-alt"></i>
                                            </button>
                                        </form>

                                    </td>
                                </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <div class="col-md-9 mb-4">
            <div class="card">
                <div class="card-header">
                    <div class="row">
                        <div class="col-md-6">
                            <i class="fa fa-receipt"></i> Pembayaran
                        </div>
                    </div>
                </div>
                <form method="post" action="<?= site_url('transaksi/transaksi_add_act') ?>">
                    <div class="card-body">
                        <div class="row">
                            <?php foreach ($keranjang as $k) { ?>
                                <input type="hidden" name="id_keranjang[]" value="<?= $k->id_keranjang ?>">
                                <input type="hidden" name="id_produk[]" value="<?= $k->id_produk ?>">
                                <input type="hidden" name="qty[]" value="<?= $k->qty ?>">
                                <input type="hidden" name="harga[]" value="<?= $k->harga ?>">
                                <input type="hidden" name="total_harga[]" value="<?= $k->total_harga ?>">
                            <?php } ?>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="" class="col-form-label">Tanggal</label>
                                    <input type="datetime-local" class="form-control" name="tanggal" id="tanggal_jam" readonly>
                                </div>
                                <div class="form-group">
                                    <label for="staff" class="col-form-label">Staff</label>
                                    <input type="hidden" name="staff" value="<?= $this->session->userdata('id') ?>">
                                    <input type="text" class="form-control" value="<?= $this->session->userdata('name') ?>" readonly>
                                </div>
                                <div class="form-group">
                                    <label for="pelanggan" class="col-form-label">Pelanggan</label>
                                    <select class="form-control" name="pelanggan" id="pelanggan" required>
                                        <option value="">-- Pilih --</option>
                                        <?php foreach ($pelanggan as $p) { ?>
                                            <option value="<?= $p->id ?>"><?= $p->nama ?></option>
                                        <?php } ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="diskon" class="col-form-label">Total Belanja</label>
                                    <input type="number" class="form-control" name="total_belanja" id="total_harga" value="<?= $total_belanja_1 ?>" readonly>
                                </div>
                                <div class="form-group">
                                    <label for="diskon" class="col-form-label">Diskon</label>
                                    <input type="number" class="form-control" id="diskon" name="diskon" placeholder="masukkan diskon.." value="0">
                                </div>
                                <div class="form-group">
                                    <label for="diskon" class="col-form-label">Grand Total</label>
                                    <input type="number" class="form-control" name="grand_total" id="total_setelah_diskon" readonly>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="bayar" class="col-form-label">Bayar</label>
                                    <input type="number" class="form-control" id="total_bayar" name="bayar" placeholder="masukkan nominal.." required>
                                </div>
                                <div class="form-group mb-4">
                                    <label for="bayar" class="col-form-label">Kembalian</label>
                                    <input type="number" readonly class="form-control" id="kembalian" name="kembalian" value="0" placeholder="">
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card-footer">
                        <?php if ($keranjang_total > 0) { ?>
                            <button type="submit" class="btn btn-primary" id="alert-bayar">BAYAR</button>
                        <?php } else { ?>
                            <button class="btn btn-primary" disabled>BAYAR</button>
                        <?php } ?>
                    </div>
                </form>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card">
                <div class="card-body">
                    <h3>Total Belanja : </h3>
                    <h4>Rp. <?php
                        if ($t->total_belanja !== null) {
                            echo number_format($t->total_belanja, 0, ',', '.');
                        } else {
                            
                        }
                        ?>,-</h4>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="modal_produk">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-tittle">Pilih Produk</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">x</span>
                </button>
            </div>
            <div class="modal-body table-responsive">
                <table class="table table-bordered table-hover" id="dataTable">
                    <thead>
                        <tr>
                            <th>Nama Produk</th>
                            <th>Harga Produk</th>
                            <th>Stok</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $no = 1;
                        foreach ($produk as $p) { ?>
                            <tr>
                                <td><?= $p->nama ?></td>
                                <td>Rp.<?= number_format($p->harga, 0, ',', '.') ?>,-</td>
                                <td><?= $p->stok; ?></td>
                                <td>
                                    <button class="btn btn-primary btn-sm" id="select" data-id="<?= $p->id_produk ?>" data-produk="<?= $p->nama ?>" data-harga="<?= $p->harga ?>" data-stok="<?= $p->stok ?>">
                                        <i class="fa fa-check"></i> Pilih</button>
                                </td>
                            </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script>
    $(document).ready(function() {
        $(document).on('click', '#select', function() {
            var id_produk = $(this).data('id');
            var nama = $(this).data('produk');
            var harga = $(this).data('harga');
            var stok = $(this).data('stok');
            $('#id_produk').val(id_produk);
            $('#nama').val(nama);
            $('#harga').val(harga);
            $('#stok').val(stok);
            $('#modal_produk').modal('hide');
        })
    })

    document.addEventListener('DOMContentLoaded', function() {
        const decreaseBtn = document.getElementById('decrease');
        const increaseBtn = document.getElementById('increase');
        const quantityInput = document.getElementById('quantity');

        decreaseBtn.addEventListener('click', function() {
            let currentValue = parseInt(quantityInput.value);
            if (currentValue > 1) {
                quantityInput.value = currentValue - 1;
            }
        });

        increaseBtn.addEventListener('click', function() {
            let currentValue = parseInt(quantityInput.value);
            quantityInput.value = currentValue + 1;
        });
    });

    document.addEventListener('DOMContentLoaded', function() {
        const totalHargaInput = document.getElementById('total_harga');
        const totalBayarInput = document.getElementById('total_bayar');
        const kembalianInput = document.getElementById('kembalian');
        const diskonInput = document.getElementById('diskon');
        const totalSetelahDiskonElement = document.getElementById('total_setelah_diskon');

        // Fungsi untuk mengupdate tampilan total setelah diskon
        function updateTotalSetelahDiskon() {
            const totalHarga = parseFloat(totalHargaInput.value);
            const diskon = parseFloat(diskonInput.value);
            const totalSetelahDiskon = totalHarga - diskon;

            totalSetelahDiskonElement.value = totalSetelahDiskon;
        }

        // Panggil fungsi untuk pertama kali
        updateTotalSetelahDiskon();

        // Tambahkan event listener untuk memperbarui saat nilai diskon berubah
        diskonInput.addEventListener('input', function() {
            updateTotalSetelahDiskon();
        });

        // Tambahkan event listener untuk memperbarui saat nilai bayar berubah
        totalBayarInput.addEventListener('input', function() {
            const totalHarga = parseFloat(totalHargaInput.value);
            const diskon = parseFloat(diskonInput.value);
            const totalBayar = parseFloat(totalBayarInput.value);
            const totalSetelahDiskon = totalHarga - diskon;
            const kembalian = totalBayar - totalSetelahDiskon;

            kembalianInput.value = kembalian.toFixed();
        });
    });



    document.addEventListener('DOMContentLoaded', function() {
        const tanggalJamDetikInput = document.getElementById('tanggal_jam');

        // Fungsi untuk memperbarui tanggal, jam, dan detik setiap detik
        function updateDateTime() {
            const now = new Date();

            const tahun = now.getFullYear();
            const bulan = String(now.getMonth() + 1).padStart(2, '0');
            const tanggal = String(now.getDate()).padStart(2, '0');
            const jam = String(now.getHours()).padStart(2, '0');
            const menit = String(now.getMinutes()).padStart(2, '0');
            const detik = String(now.getSeconds()).padStart(2, '0');

            const tanggalJamDetikFormatted = `${tahun}-${bulan}-${tanggal}T${jam}:${menit}:${detik}`;
            tanggalJamDetikInput.value = tanggalJamDetikFormatted;
        }

        // Panggil fungsi untuk pertama kali dan lalu set interval untuk memperbarui setiap detik
        updateDateTime();
        setInterval(updateDateTime, 1000);
    });
</script>