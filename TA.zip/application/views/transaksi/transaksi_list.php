 <!-- Begin Page Content -->
 <div class="container-fluid">

     <!-- Page Heading -->
     <div class="d-sm-flex align-items-center justify-content-between mb-4">
         <h1 class="h3 mb-0 text-gray-800">Transaksi List</h1>
     </div>

     <div class="card">
         <?php if ($this->session->userdata('access') == 'Staff') { ?>
             <div class="card-header">
                 <a href="<?= base_url('transaksi/transaksi_add'); ?>" class="btn btn-primary btn-sm"><i class="fa fa-plus"></i> Transaksi Baru</a>
             </div>
         <?php } ?>
         <div class="card-body">


             <table class="table table-bordered" id="dataTable">
                 <thead>
                     <tr>
                         <th style="width: 1%;">No</th>
                         <th>Tanggal</th>
                         <th>Staff</th>
                         <th>Pelanggan</th>
                         <th class="text-center">Grand Total</th>
                         <th class="text-center">Jumlah Produk</th>
                         <th class="text-center">Status</th>
                         <th class="text-center" style="width: 16%;">Aksi</th>
                     </tr>
                 </thead>
                 <tbody>
                     <?php $no = 1;
                        foreach ($transaksi as $t) {
                            $this->db->select('id_transaksi, COUNT(id_jumlah_produk) as jumlah_produk');
                            $this->db->from('jumlah_produk_transaksi');
                            $this->db->where('id_transaksi', $t->id_transaksi);
                            $produk = $this->db->get()->result();
                            foreach ($produk as $p) {
                                $jumlah_produk = $p->jumlah_produk;
                            }
                        ?>
                         <tr>
                             <td class="text-center"><?= $no++; ?></td>
                             <td><?= date('d F Y H:i:s', strtotime($t->tgl_transaksi)); ?></td>
                             <td><?= $t->user_name; ?></td>
                             <td><?= $t->nama; ?></td>
                             <td class="text-center">Rp.<?= number_format($t->grand_total, 0, ',', '.') ?>,-</td>
                             <td class="text-center"><?= $jumlah_produk; ?> Produk</td>
                             <td class="text-center">
                                 <?php if ($t->status_pengiriman == 0) { ?>
                                     <span class=" badge badge-warning">Belum Dikirim</span>
                                 <?php } else if ($t->status_pengiriman == 1) { ?>
                                     <span class=" badge badge-primary">Sedang Dikirim</span>
                                 <?php } else { ?>
                                     <span class=" badge badge-success">Selesai</span>
                                 <?php } ?>
                             </td>
                             <td class="text-center">
                                 <a href="<?= site_url('transaksi/transaksi_detail/' . $t->id_transaksi) ?>" class="btn btn-sm btn-info"><i class="fa fa-list-alt"></i> Detail</a>
                                 <?php if ($t->status_pengiriman == 0) { ?>
                                     <a href="<?= site_url('transaksi/kirim/' . $t->id_transaksi) ?>" class="btn btn-sm btn-primary" id="alert-kirim"><i class="fa fa-truck"></i> Kirim</a>
                                 <?php } ?>
                             </td>
                         </tr>
                     <?php } ?>
                 </tbody>
             </table>
         </div>
     </div>
 </div>