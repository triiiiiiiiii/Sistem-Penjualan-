<?php foreach ($transaksi_detail as $t) {
    $tanggal = $t->tgl_transaksi;
    $status = $t->status_pengiriman;
    $staff = $t->user_name;
    $pelanggan = $t->nama;
    $no_telpon = $t->telefon;
    $alamat = $t->alamat;
    $jumlah = $t->jumlah_produk;
    $total_belanja = $t->total_belanja;
    $diskon = $t->diskon;
    $grand_total = $t->grand_total;
    $bayar = $t->bayar;
    $kembalian = $t->kembalian;
} ?>


<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Transaksi Detail</h1>
    </div>

    <div class="card">
        <!-- <div class="card-header">
            <a href="<?= site_url('transaksi') ?>" class="btn btn-secondary"><i class="fa fa-arrow-left"></i> Kembali</a>
            <a href="<?= site_url('transaksi') ?>" class="btn btn-primary"><i class="fa fa-receipt"></i> I N V O I C E</a>
        </div> -->
        <div class="card-body">
            <div class="row">
                <div class="col-md-8">

                    <table width="100%">
                        <tr style="height: 40px;">
                            <td style="width: 20%;">Tanggal Transaksi</td>
                            <td style="width: 1%;">:</td>
                            <td><?= $tanggal ?></td>
                        </tr>
                        <tr style="height: 40px;">
                            <td>Status</td>
                            <td>:</td>
                            <td>
                                <?php if ($status == 0) { ?>
                                    <span class=" badge badge-warning">Belum Dikirim</span>
                                <?php } elseif ($status == 1) { ?>
                                    <span class=" badge badge-primary">Sedang Dikirim</span>
                                <?php } else { ?>
                                    <span class=" badge badge-success">Selesai</span>
                                <?php } ?>
                            </td>
                        </tr>
                        <tr style="height: 40px;">
                            <td>Staff</td>
                            <td>:</td>
                            <td><?= $staff ?></td>
                        </tr>
                        <tr style="height: 40px;">
                            <td>Nama Pelanggan</td>
                            <td>:</td>
                            <td><?= $pelanggan ?></td>
                        </tr>
                        <tr style="height: 40px;">
                            <td>No Telpon</td>
                            <td>:</td>
                            <td><?= $no_telpon ?></td>
                        </tr>
                        <tr style="height: 40px;">
                            <td>Alamat</td>
                            <td>:</td>
                            <td><?= $alamat ?></td>
                        </tr>
                    </table>
                </div>
                <div class="col-md-4">
                    <table width="100%">
                        <tr style="height: 30px;">
                            <td style="width: 40%;">Total Belanja</td>
                            <td style="width: 1%;">:</td>
                            <td>Rp. <?= number_format($total_belanja, 0, ',', '.') ?>,-</td>
                        </tr>
                        <tr style="height: 30px;">
                            <td>Diskon</td>
                            <td>:</td>
                            <td>Rp. <?= number_format($diskon, 0, ',', '.') ?>,-</td>
                        </tr>
                        <tr style="height: 30px;">
                            <td>Grand Total</td>
                            <td>:</td>
                            <td>Rp. <?= number_format($grand_total, 0, ',', '.') ?>,-</td>
                        </tr>
                    </table>
                    <hr>
                    <table width="100%">
                        <tr style="height: 30px;">
                            <th style="width: 40%;">Total Bayar</th>
                            <th style="width: 1%;">:</th>
                            <th>Rp. <?= number_format($bayar, 0, ',', '.') ?>,-</th>
                        </tr>
                        <tr style="height: 30px;">
                            <td>Kembalian</td>
                            <td>:</td>
                            <td>Rp. <?= number_format($kembalian, 0, ',', '.') ?>,-</td>
                        </tr>
                    </table>
                </div>
            </div>
            <hr>
            <div class="card">
                <div class="card-header">
                    Produk Yang Dibeli : <b><?= $jumlah ?> Produk</b>
                </div>
                <div class="card-body">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Nama Produk</th>
                                <th>QTY</th>
                                <th>Harga</th>
                                <th>Total Harga</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $no = 1;
                            foreach ($jumlah_produk as $jp) { ?>
                                <tr>
                                    <td><?= $no++ ?></td>
                                    <td><?= $jp->nama ?></td>
                                    <td><?= $jp->qty ?></td>
                                    <td>Rp. <?= number_format($jp->harga, 0, ',', '.') ?>,-</td>
                                    <td>Rp. <?= number_format($jp->total_harga, 0, ',', '.') ?>,-</td>
                                </tr>
                            <?php } ?>
                        </tbody>
                        <thead>
                            <tr>
                                <th class="text-right" colspan="4">Total Belanja : </th>
                                <th>Rp. <?= number_format($total_belanja, 0, ',', '.') ?>,-</th>
                            </tr>
                        </thead>
                    </table>
                </div>
            </div>
            <hr>
        </div>
    </div>
</div>