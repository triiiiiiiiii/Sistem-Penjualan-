 </div>
 <!-- End of Main Content -->

 <!-- Footer -->
 <footer class="sticky-footer bg-white">
     <div class="container my-auto">
         <div class="copyright text-center my-auto">
             <span>Copyright &copy; CV. Intip Kendil Emas 2023</span>
         </div>
     </div>
 </footer>
 <!-- End of Footer -->

 </div>
 <!-- End of Content Wrapper -->

 </div>
 <!-- End of Page Wrapper -->

 <!-- Scroll to Top Button-->
 <a class="scroll-to-top rounded" href="#page-top">
     <i class="fas fa-angle-up"></i>
 </a>

 <!-- Bootstrap core JavaScript-->
 <script src="<?= base_url('assets/vendor/jquery/jquery.min.js') ?>"></script>
 <script src="<?= base_url('assets/vendor/bootstrap/js/bootstrap.bundle.min.js') ?>"></script>

 <!-- Core plugin JavaScript-->
 <script src="<?= base_url('assets/vendor/jquery-easing/jquery.easing.min.js') ?>"></script>

 <!-- Custom scripts for all pages-->
 <script src="<?= base_url('assets/js/sb-admin-2.min.js') ?>"></script>

 <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
 <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.min.js"></script>

 <!-- Page level plugins -->
 <script src="<?= base_url('assets/vendor/datatables/jquery.dataTables.min.js') ?>"></script>
 <script src="<?= base_url('assets/vendor/datatables/dataTables.bootstrap4.min.js') ?>"></script>

 <!-- Page level custom scripts -->
 <script src="<?= base_url('assets/js/demo/datatables-demo.js') ?>"></script>

 <script type="text/javascript" src="<?= base_url('assets/sweetalert2/sweetalert2.js') ?>"></script>

 <script>
     // Data Tables
     $(document).ready(function() {
         $('#data-table').DataTable();
     });

     var flash = $('#success').data('flash');

     if (flash) {
         Swal.fire({
             icon: 'success',
             title: 'Success',
             text: flash,
         })
     }

     var gagal = $('#warning').data('flash');

     if (gagal) {
         Swal.fire({
             icon: 'warning',
             title: 'Peringatan',
             text: gagal,
         })
     }

     var gagal = $('#failed').data('flash');

     if (gagal) {
         Swal.fire({
             icon: 'error',
             title: 'Gagal',
             text: gagal,
         })
     }

     $(document).on('click', '#alert-logout', function(e) {
         e.preventDefault();
         var getLink = $(this).attr('href');

         swal.fire({
             icon: 'question',
             title: 'Yakin Ingin Logout?',
             text: 'Anda akan keluar dari halaman Web',
             confirmButtonText: 'Ya',
             cancelButtonText: 'Tidak',
             buttonWidth: 20,
             showCancelButton: true,
         }).then((result) => {
             if (result.isConfirmed) {
                 window.location.href = getLink;
             }
         });
     });

     $(document).on('click', '#alert-hapus', function(e) {
         e.preventDefault();
         var getLink = $(this).attr('href');

         swal.fire({
             icon: 'question',
             title: 'Yakin Hapus Ini?',
             text: 'Data akan dihapus dari Database',
             confirmButtonText: 'Ya',
             cancelButtonText: 'Tidak',
             confirmButtonCollor: 'btn btn-danger',
             buttonWidth: 20,
             showCancelButton: true,
         }).then((result) => {
             if (result.isConfirmed) {
                 window.location.href = getLink;
             }
         });
     });

     $(document).on('click', '#alert-kirim', function(e) {
         e.preventDefault();
         var getLink = $(this).attr('href');

         swal.fire({
             icon: 'question',
             title: 'Yakin Ingin Kirim?',
             text: 'Produk akan dikirim ke pelanggan',
             confirmButtonText: 'Ya',
             cancelButtonText: 'Tidak',
             confirmButtonCollor: 'btn btn-danger',
             buttonWidth: 20,
             showCancelButton: true,
         }).then((result) => {
             if (result.isConfirmed) {
                 window.location.href = getLink;
             }
         });
     });

     $(document).on('click', '#alert-selesai-kirim', function(e) {
         e.preventDefault();
         var getLink = $(this).attr('href');

         swal.fire({
             icon: 'question',
             title: 'Yakin Selesaikan Pengiriman?',
             text: 'Pastikan pelanggan telah menerima produk',
             confirmButtonText: 'Ya',
             cancelButtonText: 'Tidak',
             confirmButtonCollor: 'btn btn-danger',
             buttonWidth: 20,
             showCancelButton: true,
         }).then((result) => {
             if (result.isConfirmed) {
                 window.location.href = getLink;
             }
         });
     });

     $(document).on('click', 'form #alert-bayar', function(e) {
         let $form = $(this).closest('form');
         e.preventDefault();
         var getLink = $(this).attr('href');

         swal.fire({
             icon: 'question',
             title: 'Yakin Ingin Bayar?',
             text: 'Pastikan semua data sudah benar',
             confirmButtonText: 'Ya',
             cancelButtonText: 'Tidak',
             buttonWidth: 20,
             showCancelButton: true,
         }).then((result) => {
             if (result.value) {
                 $form.submit();
             }

         });
     });

     $(document).on('click', 'form #alert-hapus-file', function(e) {
         let $form = $(this).closest('form');
         e.preventDefault();
         var getLink = $(this).attr('href');

         swal.fire({
             icon: 'warning',
             title: 'Yakin Hapus Ini?',
             text: 'Data akan dihapus dari Database',
             confirmButtonText: 'Ya',
             cancelButtonText: 'Tidak',
             buttonWidth: 20,
             showCancelButton: true,
         }).then((result) => {
             if (result.value) {
                 $form.submit();
             }

         });
     });

     $(document).on('click', '#nonaktifkan', function(e) {
         e.preventDefault();
         var getLink = $(this).attr('href');

         swal.fire({
             icon: 'warning',
             title: 'Yakin Nonaktifkan?',
             text: 'Admin akan dinonaktifkan',
             confirmButtonText: 'Ya',
             cancelButtonText: 'Tidak',
             buttonWidth: 20,
             showCancelButton: true,
         }).then((result) => {
             if (result.isConfirmed) {
                 window.location.href = getLink;
             }
         });
     });

     $(document).on('click', '#aktifkan', function(e) {
         e.preventDefault();
         var getLink = $(this).attr('href');

         swal.fire({
             icon: 'warning',
             title: 'Yakin Aktifkan?',
             text: 'Admin akan diaktifkan',
             confirmButtonText: 'Ya',
             cancelButtonText: 'Tidak',
             buttonWidth: 20,
             showCancelButton: true,
         }).then((result) => {
             if (result.isConfirmed) {
                 window.location.href = getLink;
             }
         });
     });

     $(document).on('click', 'form #selesaikan', function(e) {
         let $form = $(this).closest('form');
         e.preventDefault();
         var getLink = $(this).attr('href');

         swal.fire({
             icon: 'warning',
             title: 'Yakin Selesaikan?',
             text: 'Peminjaman akan diselesaikan',
             confirmButtonText: 'Ya',
             cancelButtonText: 'Tidak',
             buttonWidth: 20,
             showCancelButton: true,
         }).then((result) => {
             if (result.value) {
                 $form.submit();
             }

         });
     });

     // Example starter JavaScript for disabling form submissions if there are invalid fields
     (function() {
         'use strict'

         // Fetch all the forms we want to apply custom Bootstrap validation styles to
         var forms = document.querySelectorAll('.needs-validation')

         // Loop over them and prevent submission
         Array.prototype.slice.call(forms)
             .forEach(function(form) {
                 form.addEventListener('submit', function(event) {
                     if (!form.checkValidity()) {
                         event.preventDefault()
                         event.stopPropagation()
                     }

                     form.classList.add('was-validated')
                 }, false)
             })
     })()
 </script>

 </body>

 </html>