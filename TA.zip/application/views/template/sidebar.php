 <!-- Page Wrapper -->
 <div id="wrapper">

     <!-- Sidebar -->
     <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

         <!-- Sidebar - Brand -->
         <a class="sidebar-brand d-flex align-items-center justify-content-center" href="index.html">
             <div class="sidebar-brand-icon rotate-n-15">
                 <i class="fas fa-laugh-wink"></i>
             </div>
             <div class="sidebar-brand-text mx-3">CV. Intip Kendil Emas<sup></sup></div>
         </a>

         <!-- Divider -->
         <hr class="sidebar-divider my-0">

         <!-- Nav Item - Dashboard -->
         <li class="nav-item <?php if ($this->uri->segment(1) == "dashboard") {
                                    echo "active";
                                } ?>">
             <a class="nav-link" href="<?= site_url('dashboard') ?>">
                 <i class="fas fa-fw fa-tachometer-alt"></i>
                 <span>Dashboard</span></a>
         </li>

         <!-- Divider -->
         <hr class="sidebar-divider">

         <!-- Heading -->
         <div class="sidebar-heading">
             Interface
         </div>

         <!-- Nav Item - Pages Collapse Menu -->
         <?php if ($this->session->userdata('access') == 'Admin') { ?>
             <li class="nav-item <?php if ($this->uri->segment(1) == "produk" || $this->uri->segment(1) == "produk_masuk") {
                                        echo "active";
                                    } ?>">
                 <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                     <i class="fas fa-fw fa-cog"></i>
                     <span>Manajemen Produk</span>
                 </a>
                 <div id="collapseOne" class="collapse <?php if ($this->uri->segment(1) == "produk" || $this->uri->segment(1) == "produk_masuk") {
                                                            echo "show";
                                                        } ?>" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                     <div class="bg-white py-2 collapse-inner rounded">
                         <a class="collapse-item  <?php if ($this->uri->segment(1) == "produk") {
                                                        echo "active";
                                                    } ?>" href="<?= site_url('produk') ?>">List Produk</a>

                         <a class="collapse-item  <?php if ($this->uri->segment(1) == "produk_masuk") {
                                                        echo "active";
                                                    } ?>" href="<?= site_url('produk_masuk') ?>">Produk Masuk</a>
                     </div>
                 </div>
             </li>
         <?php } else { ?>
             <li class="nav-item  <?php if ($this->uri->segment(1) == "produk") {
                                        echo "active";
                                    } ?>">
                 <a class="nav-link" href="<?= site_url('produk') ?>">
                     <i class="fas fa-fw fa-box"></i>
                     <span>List Produk</span></a>
             </li>
         <?php } ?>

         <!-- <li class="nav-item  <?php if ($this->uri->segment(1) == "pelanggan") {
                                    echo "active";
                                } ?>">
             <a class="nav-link" href="<?= site_url('pelanggan') ?>">
                 <i class="fas fa-fw fa-user"></i>
                 <?php if ($this->session->userdata('access') == 'Admin') { ?>
                     <span>Manajemen Pelanggan</span>
                 <?php } else { ?>
                     <span>List Pelanggan</span>
                 <?php } ?>
             </a>
         </li> -->
        
        <?php if ($this->session->userdata('access') == 'Admin') { ?>
         <li class="nav-item <?php if ($this->uri->segment(1) == "pelanggan") {
            echo "active";
        } ?>">
         <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#pelanggan" aria-expanded="true" aria-controls="collapseUtilities">
        <i class="fas fa-fw fa-shopping-cart"></i>
        <span>Manajemen pelanggan</span>
        </a>
            <div id="pelanggan" class="collapse <?php if ($this->uri->segment(1) == "pelanggan") {
                                                        echo "show";
                                                    } ?>" aria-labelledby="headingUtilities" data-parent="#accordionSidebar">
                <div class="bg-white py-2 collapse-inner rounded">
                    <a class="collapse-item <?php if ($this->uri->segment(2) == "pelanggan_add") {
                                                    echo "active";
                                                } ?>" href="<?= site_url('pelanggan/pelanggan_add') ?>">Tambah Pelanggan</a>
                    <a class="collapse-item <?php if ($this->uri->segment(2) == "pelanggan") {
                                                    echo "active";
                                                } ?>" href="<?= site_url('pelanggan') ?>">List Pelanggan</a>
            </li>
        <?php } ?>

        <?php if ($this->session->userdata('access') == 'Staff') { ?>
        <li class="nav-item <?php if ($this->uri->segment(1) == "pelanggan") {
            echo "active";
        } ?>">
         <a class="nav-link collapsed" href="<?= site_url('pelanggan') ?>"  aria-controls="collapseUtilities">
        <i class="fas fa-fw fa-user"></i>
        <span>List pelanggan</span>
        </a>
        <?php } ?>
        
        

         <!-- <?php if ($this->session->userdata('access') == 'Admin') { ?>
             <li class="nav-item  <?php if ($this->uri->segment(1) == "user") {
                                        echo "active";
                                    } ?>">
                 <a class="nav-link" href="<?= site_url('user') ?>">
                     <i class="fas fa-fw fa-user"></i>
                     <span>Manajemen User</span></a>
             </li>
         <?php } ?> -->

         <?php if ($this->session->userdata('access') == 'Admin') { ?>
         <li class="nav-item <?php if ($this->uri->segment(1) == "pelanggan") {
            echo "active";
        } ?>">
         <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#user" aria-expanded="true" aria-controls="collapseUtilities">
        <i class="fas fa-fw fa-user"></i>
        <span>Manajemen User</span>
        </a>
            <div id="user" class="collapse <?php if ($this->uri->segment(1) == "pelanggan") {
                                                        echo "show";
                                                    } ?>" aria-labelledby="headingUtilities" data-parent="#accordionSidebar">
                <div class="bg-white py-2 collapse-inner rounded">
                    <a class="collapse-item <?php if ($this->uri->segment(2) == "pelanggan_add") {
                                                    echo "active";
                                                } ?>" href="<?= site_url('user') ?>">List User</a>
                    <a class="collapse-item <?php if ($this->uri->segment(2) == "pelanggan") {
                                                    echo "active";
                                                } ?>" href="<?= site_url('user/user_add') ?>">Register User</a>
            </li>
        <?php } ?>

         <?php if ($this->session->userdata('access') == 'Staff') { ?>

         <!-- <li class="nav-item  <?php if ($this->uri->segment(1) == "transaksi") {
                                    echo "active";
                                } ?>">
             <a class="nav-link" href="<?= site_url('transaksi') ?>">
                 <i class="fas fa-fw fa-receipt"></i>
                 <span>Transaksi</span></a>
         </li>
         <li class="nav-item  <?php if ($this->uri->segment(1) == "pengiriman") {
                                    echo "active";
                                } ?>">
             <a class="nav-link" href="<?= site_url('pengiriman') ?>">
                 <i class="fas fa-fw fa-truck"></i>
                 <span>Pengiriman</span></a>
         </li> -->
         <li class="nav-item <?php if ($this->uri->segment(1) == "transaksi" || $this->uri->segment(1) == "pengiriman") {
            echo "active";
        } ?>">
         <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#manajemen_transaksi" aria-expanded="true" aria-controls="collapseUtilities">
        <i class="fas fa-fw fa-shopping-cart"></i>
        <span>Manajemen Transaksi</span>
        </a>
            <div id="manajemen_transaksi" class="collapse <?php if ($this->uri->segment(1) == "transaksi" || $this->uri->segment(1) == "pengiriman") {
                                                        echo "show";
                                                    } ?>" aria-labelledby="headingUtilities" data-parent="#accordionSidebar">
                <div class="bg-white py-2 collapse-inner rounded">
                    <a class="collapse-item <?php if ($this->uri->segment(1) == "transaksi") {
                                                    echo "active";
                                                } ?>" href="<?= site_url('transaksi') ?>">Transaksi</a>
                    <a class="collapse-item <?php if ($this->uri->segment(1) == "pengiriman") {
                                                    echo "active";
                                                } ?>" href="<?= site_url('pengiriman') ?>">Pengiriman</a>
            </li>
         <?php } ?>

         <?php if ($this->session->userdata('access') == 'Admin') { ?>
             <li class="nav-item <?php if ($this->uri->segment(1) == "laporan") {
                                        echo "active";
                                    } ?>">
                 <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="true" aria-controls="collapseTwo">
                     <i class="fas fa-fw fa-book"></i>
                     <span>Laporan</span>
                 </a>
                 <div id="collapseTwo" class="collapse <?php if ($this->uri->segment(1) == "laporan") {
                                                            echo "show";
                                                        } ?>" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                     <div class="bg-white py-2 collapse-inner rounded">
                         <a class="collapse-item  <?php if ($this->uri->segment(2) == "laporan_produk_masuk") {
                                                        echo "active";
                                                    } ?>" href="<?= site_url('laporan/laporan_produk_masuk') ?>">Laporan Produk Masuk</a>

                         <a class="collapse-item  <?php if ($this->uri->segment(2) == "laporan_transaksi") {
                                                        echo "active";
                                                    } ?>" href="<?= site_url('laporan/laporan_transaksi') ?>">Laporan Transaksi</a>
                     </div>
                 </div>
             </li>
         <?php } ?>
         <!-- Divider -->
         <hr class="sidebar-divider d-none d-md-block">

         <!-- Sidebar Toggler (Sidebar) -->
         <div class="text-center d-none d-md-inline">
             <button class="rounded-circle border-0" id="sidebarToggle"></button>
         </div>


     </ul>
     <!-- End of Sidebar -->

     <!-- Content Wrapper -->
     <div id="content-wrapper" class="d-flex flex-column">

         <!-- Main Content -->
         <div id="content">

             <!-- Topbar -->
             <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

                 <!-- Sidebar Toggle (Topbar) -->
                 <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                     <i class="fa fa-bars"></i>
                 </button>

                 <!-- Topbar Search -->
                 <form class="d-none d-sm-inline-block form-inline mr-auto ml-md-3 my-2 my-md-0 mw-100 navbar-search">
                     <div class="input-group">
                         <ul class="navbar-nav float-left mr-auto ml-3 pl-1">
                             <li class="nav-item d-none d-md-block">
                                 <a class="nav-link" href="javascript:void(0)">
                                     <button type="button" class="btn btn-rounded btn-light"><i class="fas fa-user"></i> &nbsp;Anda sebagai <?= $this->session->userdata('access') ?></button>
                                 </a>
                             </li>
                         </ul>
                     </div>
                 </form>

                 <!-- Topbar Navbar -->
                 <ul class="navbar-nav ml-auto">

                     <!-- Nav Item - Search Dropdown (Visible Only XS) -->
                     <li class="nav-item dropdown no-arrow d-sm-none">
                         <a class="nav-link dropdown-toggle" href="#" id="searchDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                             <i class="fas fa-search fa-fw"></i>
                         </a>
                         <!-- Dropdown - Messages -->
                         <div class="dropdown-menu dropdown-menu-right p-3 shadow animated--grow-in" aria-labelledby="searchDropdown">
                             <form class="form-inline mr-auto w-100 navbar-search">
                                 <div class="input-group">
                                     <input type="text" class="form-control bg-light border-0 small" placeholder="Search for..." aria-label="Search" aria-describedby="basic-addon2">
                                     <div class="input-group-append">
                                         <button class="btn btn-primary" type="button">
                                             <i class="fas fa-search fa-sm"></i>
                                         </button>
                                     </div>
                                 </div>
                             </form>
                         </div>
                     </li>

                     <div class="topbar-divider d-none d-sm-block"></div>

                     <!-- Nav Item - User Information -->
                     <li class="nav-item dropdown no-arrow">
                         <a class="nav-link dropdown-toggle" href="javascript:void(0)" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                             <img src="<?= $this->session->userdata('role') == 'admin' ? base_url('assets/images/navbar/admin.png') : base_url('assets/images/navbar/user.png') ?>" alt="user" class="rounded-circle" width="40">
                             <span class="ml-2 d-none d-lg-inline-block">
                                 <span>Hallo,</span>
                                 <span class="text-dark"><?= $this->session->userdata('name') ?></span>
                                 <i data-feather="chevron-down" class="svg-icon"></i>
                             </span>
                         </a>
                         <!-- Dropdown - User Information -->
                         <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">
                             <a class="dropdown-item" href="#">
                                 <i class="fas fa-cogs fa-sm fa-fw mr-2 text-gray-400"></i>
                                 Settings
                             </a>
                             <div class="dropdown-divider"></div>
                             <a class="dropdown-item" href="<?= site_url('login/logout') ?>" id="alert-logout">
                                 <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                                 Logout
                             </a>
                         </div>
                     </li>

                 </ul>

             </nav>
             <!-- End of Topbar -->

             <div id="success" data-flash="<?= $this->session->flashdata('success'); ?>"></div>
             <div id="warning" data-flash="<?= $this->session->flashdata('warning'); ?>"></div>
             <div id="failed" data-flash="<?= $this->session->flashdata('failed'); ?>"></div>