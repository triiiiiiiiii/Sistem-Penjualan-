 <!-- Begin Page Content -->
 <div class="container-fluid">
     <!-- Page Heading -->
     <div class="d-sm-flex align-items-center justify-content-between mb-4">
         <h1 class="h3 mb-0 text-gray-800">Edit Pelanggan</h1>
     </div>
     <div class="card">
         <form method="post" action="<?php echo base_url('pelanggan/pelanggan_edit_act'); ?>">
             <?php foreach ($pelanggan as $p) { ?>
                 <div class="card-body">
                     <div class="form-group">
                         <div class="row">
                             <label for="nama" class="col-form-label col-md-2">Nama Lengkap</label>
                             <div class="col-md-10">
                                 <div class="input-group">
                                     <div class="input-group-prepend">
                                         <span class="input-group-text"><i class="fa fa-user"></i></span>
                                     </div>
                                     <input type="hidden" name="id_pelanggan" value="<?= $p->id_pelanggan ?>">
                                     <input type="text" class="form-control" name="nama" id="nama" value="<?= $p->nama ?>" placeholder="masukkan nama pelanggan.." required>
                                 </div>
                             </div>
                         </div>
                     </div>
                     <div class="form-group">
                         <div class="row">
                             <label for="email" class="col-form-label col-md-2">E-mail</label>
                             <div class="col-md-10">
                                 <div class="input-group">
                                     <div class="input-group-prepend">
                                         <span class="input-group-text"><b>@</b></span>
                                     </div>
                                     <input type="email" class="form-control" name="email" value="<?= $p->email ?>" id="email" placeholder="masukkan email.." required>
                                 </div>
                             </div>
                         </div>
                     </div>
                     <div class="form-group">
                         <div class="row">
                             <label for="telefon" class="col-form-label col-md-2">No Telpon</label>
                             <div class="col-md-10">
                                 <div class="input-group">
                                     <div class="input-group-prepend">
                                         <span class="input-group-text"><i class="fa fa-phone"></i></span>
                                     </div>
                                     <input type="text" class="form-control" name="telefon" id="telefon" value="<?= $p->telefon ?>" placeholder="masukkan no telpon.." required>
                                 </div>
                             </div>
                         </div>
                     </div>
                     <div class="form-group">
                         <div class="row">
                             <label for="alamat" class="col-form-label col-md-2">Alamat</label>
                             <div class="col-md-10">
                                 <div class="input-group">
                                     <div class="input-group-prepend">
                                         <span class="input-group-text"><i class="fa fa-address-card"></i></span>
                                     </div>
                                     <input type="text" class="form-control" name="alamat" id="alamat" value="<?= $p->alamat ?>" placeholder="masukkan alamat.." required>
                                 </div>
                             </div>
                         </div>
                     </div>
                     <div class="form-group">
                         <div class="row">
                             <label for="status" class="col-form-label col-md-2">Status</label>
                             <div class="col-md-10">
                                 <div class="input-group">
                                     <div class="input-group-prepend">
                                         <span class="input-group-text"><i class="fa fa-address-card"></i></span>
                                     </div>
                                     <select class="form-control" id="status" name="status" required>
                                         <option value="">-- Pilih --</option>
                                         <?php if ($p->status == 'aktif') { ?>
                                             <option value="aktif" selected>Aktif</option>
                                             <option value="nonaktif">Nonaktif</option>
                                         <?php } else { ?>
                                             <option value="aktif">Aktif</option>
                                             <option value="nonaktif" selected>Nonaktif</option>
                                         <?php } ?>
                                     </select>
                                 </div>
                             </div>
                         </div>
                     </div>
                 </div>
                 <div class="card-footer text-right">
                     <button type="submit" class="btn btn-primary"><i class="fa fa-save"></i> Simpan</button>
                     <button type="reset" class="btn btn-secondary">Reset</button>
                 </div>
             <?php } ?>
         </form>
     </div>
 </div>