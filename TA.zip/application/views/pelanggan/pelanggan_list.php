 <!-- Begin Page Content -->
 <div class="container-fluid">

     <!-- Page Heading -->
     <div class="d-sm-flex align-items-center justify-content-between mb-4">
         <h1 class="h3 mb-0 text-gray-800">Pelanggan List</h1>
     </div>

     <div class="card">
         <?php if ($this->session->userdata('access') == 'Admin') { ?>
             <div class="card-header">
                 <a class="btn btn-primary btn-sm" href="<?= site_url('pelanggan/pelanggan_add'); ?>"><i class="fa fa-user-plus"></i> Pelanggan Baru</a>
             </div>
         <?php } ?>
         <div class="card-body">
             <table class="table table-bordered" id="dataTable">
                 <thead>
                     <tr>
                         <th class="text-center" style="width: 1%;">No</th>
                         <th>Nama Pelanggan</th>
                         <th>E-mail</th>
                         <th class="text-center">No Telpon</th>
                         <th>Alamat</th>
                         <th>Status</th>
                         <?php if ($this->session->userdata('access') == 'Admin') { ?>
                         <th class="text-center" style="width: 15%;">Aksi</th>
                         <?php } ?>
                     </tr>
                 </thead>
                 <tbody>
                     <?php
                        $no = 1;
                        foreach ($pelanggan as $p) { ?>
                         <tr>
                             <td class="text-center"><?= $no++; ?></td>
                             <td><?= $p->nama; ?></td>
                             <td><?= $p->email; ?></td>
                             <td class="text-center"><?= $p->telefon; ?></td>
                             <td><?= $p->alamat; ?></td>
                             <td class="text-center">
                                 <?php if ($p->status == 'aktif') { ?>
                                     <span class="badge badge-success">Aktif</span>
                                 <?php } else { ?>
                                     <span class="badge badge-danger">Nonaktif</span>
                                 <?php } ?>
                             </td><?php if ($this->session->userdata('access') == 'Admin') { ?>
                             <td class="text-center">
                                 <a class="btn btn-warning btn-sm" href="<?= base_url() . 'pelanggan/pelanggan_edit/' . $p->id_pelanggan; ?>"><i class="fa fa-edit-alt"></i> Edit</a>
                                 <a class="btn btn-danger btn-sm" href="<?= base_url() . 'pelanggan/pelanggan_hapus/' . $p->id_pelanggan; ?>" id="alert-hapus"><i class="fa fa-trash-alt"></i> Hapus</a>
                             </td><?php } ?>
                         </tr>
                     <?php } ?>
                 </tbody>
             </table>
         </div>
     </div>
 </div>

 <!-- MODAL TAMBAH PRODUK -->
 <div class="modal fade" id="modal_pelanggan_baru">
     <div class="modal-dialog modal-dialog-centered modal-md">
         <div class="modal-content">
             <div class="modal-header">
                 <h4 class="modal-tittle">Tambah Pelanggan Baru</h4>
                 <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                     <span aria-hidden="true">x</span>
                 </button>
             </div>
             <form method="post" action="<?= base_url('pelanggan/pelanggan_add_act'); ?>">
                 <div class="modal-body table-responsive">
                     <div class="form-group">
                         <label for="nama" class="col-form-label">Nama Pelanggan</label>
                         <input type="text" class="form-control" name="nama" id="nama" placeholder="masukkan nama pelanggan.." required>
                     </div>
                     <div class="form-group">
                         <label for="email" class="col-form-label">E-mail</label>
                         <input type="email" class="form-control" name="email" id="email" placeholder="masukkan email.." required>
                     </div>
                     <div class="form-group">
                         <label for="telefon" class="col-form-label">No Telpon</label>
                         <input type="text" class="form-control" name="telefon" id="telefon" placeholder="masukkan no telpon.." required>
                     </div>
                     <div class="form-group">
                         <label for="alamat" class="col-form-label">Alamat</label>
                         <textarea class="form-control" name="alamat" id="alamat" rows="2" placeholder="masukkan alamat.." required></textarea>
                     </div>
                     <div class="form-group">
                         <label for="status" class="col-form-label">Status</label>
                         <select class="form-control" id="status" name="status" required>
                             <option value="">-- Pilih --</option>
                             <option value="aktif">Aktif</option>
                             <option value="nonaktif">Nonaktif</option>
                         </select>
                     </div>
                 </div>
                 <div class="modal-footer">
                     <button type="reset" class="btn btn-secondary">Reset</button>
                     <button type="submit" class="btn btn-primary"><i class="fa fa-save"></i> Simpan</button>
                 </div>
             </form>
         </div>
     </div>
 </div>
 <!-- END MODAL TAMBAH PRODUK -->

 <!-- MODAL EDIT PRODUK -->
 <?php foreach ($pelanggan as $p) { ?>
     <div class="modal fade" id="modal_edit_pelanggan<?= $p->id_pelanggan ?>">
         <div class="modal-dialog modal-dialog-centered modal-md">
             <div class="modal-content">
                 <div class="modal-header">
                     <h4 class="modal-tittle">Edit Pelanggan</h4>
                     <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                         <span aria-hidden="true">x</span>
                     </button>
                 </div>
                 <form method="post" action="<?= base_url('pelanggan/pelanggan_edit'); ?>">
                     <div class="modal-body table-responsive">
                         <div class="form-group">
                             <label for="nama" class="col-form-label">Nama Pelanggan</label>
                             <input type="hidden" name="id_pelanggan" value="<?= $p->id_pelanggan ?>">
                             <input type="text" class="form-control" name="nama" id="nama" value="<?= $p->nama ?>" placeholder="masukkan nama pelanggan.." required>
                         </div>
                         <div class="form-group">
                             <label for="email" class="col-form-lael">E-mail</label>
                             <input type="email" class="form-control" name="email" id="email" value="<?= $p->email ?>" placeholder="masukkan harga pelanggan.." required>
                         </div>
                         <div class="form-group">
                             <label for="telefon" class="col-form-lael">No Telpon</label>
                             <input type="text" class="form-control" name="telefon" id="telefon" value="<?= $p->telefon ?>" placeholder="masukkan harga pelanggan.." required>
                         </div>
                         <div class="form-group">
                             <label for="alamat" class="col-form-lael">Alamat</label>
                             <textarea class="form-control" name="alamat" id="alamat" rows="2" required><?= $p->alamat ?></textarea>
                         </div>
                         <div class="form-group">
                             <label for="status" class="col-form-label">Status</label>
                             <select class="form-control" id="status" name="status" required>
                                 <option value="">-- Pilih --</option>
                                 <?php if ($p->status == 'aktif') { ?>
                                     <option value="aktif" selected>Aktif</option>
                                     <option value="nonaktif">Nonaktif</option>
                                 <?php } else { ?>
                                     <option value="aktif">Aktif</option>
                                     <option value="nonaktif" selected>Nonaktif</option>
                                 <?php } ?>
                             </select>
                         </div>
                     </div>
                     <div class="modal-footer">
                         <button type="reset" class="btn btn-secondary">Reset</button>
                         <button type="submit" class="btn btn-primary"><i class="fa fa-save"></i> Simpan</button>
                     </div>
                 </form>
             </div>
         </div>
     </div>
 <?php } ?>
 <!-- END MODAL EDIT PRODUK -->