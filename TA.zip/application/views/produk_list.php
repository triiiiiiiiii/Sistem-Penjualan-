 <!-- Begin Page Content -->
 <div class="container-fluid">

     <!-- Page Heading -->
     <div class="d-sm-flex align-items-center justify-content-between mb-4">
         <h1 class="h3 mb-0 text-gray-800">Produk List</h1>
     </div>

     <div class="card">
         <div class="card-header">
             <a href="<?php echo base_url() . 'produk/add'; ?>" class="btn btn-primary btn-sm"><span class="glyphicon glyphicon-plus"></span> Produk Baru</a>
         </div>
         <div class="card-body">


             <table class="table table-bordered">
                 <thead>
                     <tr>
                         <th>No</th>
                         <th>Nama</th>
                         <th>Jumlah</th>
                         <th>Harga</th>
                         <th>Aksi</th>
                     </tr>
                 </thead>
                 <tbody>

                     <?php
                        $no = 1;
                        foreach ($produk as $produk) { ?>
                         <tr>
                             <td><?php echo $no++; ?></td>
                             <td><?php echo $produk->nama; ?></td>
                             <td><?php echo $produk->stok; ?> Bungkus</td>
                             <td>Rp.<?= number_format($produk->harga, 0, ',', '.') ?>,-</td>
                             <td>
                                 <a class="btn btn-dark btn-sm" href="<?php echo base_url() . 'produk_masuk/tambah/' . $produk->id_produk; ?>"><span class="glyphicon glyphicon-plus"></span>+ Stok</a>
                                 <a class="btn btn-warning btn-sm" href="<?php echo base_url() . 'produk/kostumer_edit/' . $produk->id_produk; ?>"><span class="glyphicon glyphicon-plus"></span> Edit</a>
                                 <a class="btn btn-danger btn-sm" href="<?php echo base_url() . 'produk/hapus_pelanggan/' . $produk->id_produk; ?>"><span class="glyphicon glyphicon-trash"></span> Hapus</a>

                             </td>
                         </tr>
                     <?php } ?>
                 </tbody>
             </table>
         </div>
     </div>
 </div>