<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="<?= base_url('assets/style.css') ?>">
    

</head>
<body>
    
    <div class="background">
        <div class="shape"></div>
        <div class="shape"></div>
    </div>

    <form method="POST" action="<?php echo site_url('login/autentikasi');?>">
        <h3>Login Dulu Bro</h3>
        

        <label for="username">Username</label>
        <input type="text" placeholder="Email atau Telepon" id="email" name="email" required autofocus>
        
        <label for="password">Password</label>
        <input type="password" placeholder="password" id="pass" name="pass" required>
        
        <?php echo $this->session->flashdata('msg');?>
        <button class="btn" type="submit" name="login">Log In</button>
        
        
        
    </form>
</body>
</html>

