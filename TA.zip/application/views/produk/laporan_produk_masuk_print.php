<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CV INTIP KENDIL EMAS</title>
    <link href="<?= base_url('assets/css/bootstrap.min.css') ?>" rel="stylesheet">
    <style>
        .custom-container {
            max-width: 1140px;
            /* Sesuaikan dengan lebar yang Anda inginkan */
            margin: 0 auto;
            /* Memusatkan konten di tengah */
            padding: 0 15px;
            /* Memberikan padding di sisi kiri dan kanan */
        }

        .table-bordered th,
        .table-bordered td {
            font-size: 12px;
        }
    </style>
</head>

<body>

    <br>
    <div class="custom-container">
        <table class="table">
            <thead style="font-size: 18px;">
                <tr class="">
                    <th style="padding: 0px;" class="text-center">LAPORAN PRODUK MASUK <br> CV. INTIP KENDIL EMAS <br> <span style="font-size: 12px; font-weight: 400">Dk. Sendangrejo Rt.022, Kel Jati, Kec. Sumberlawang, Kab Sragen, Telp (081335422739) Fax: -</span> </th>
                </tr>
            </thead>
            <tbody>
                <tr></tr>
            </tbody>
        </table>
        <br>
        <table class="table table-bordered" id="dataTable">
            <thead>
                <tr>
                    <th class="text-center" style="width: 1%;">No</th>
                    <th>Tanggal Masuk</th>
                    <th>Nama Produk</th>
                    <th class="text-center">Stok Masuk</th>
                    <th>Staff</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $no = 1;
                foreach ($produk_masuk as $pm) { ?>
                    <tr>
                        <td><?= $no++; ?></td>
                        <td><?= date('d F Y', strtotime($pm->tanggal_masuk)); ?></td>
                        <td><?= $pm->nama; ?></td>
                        <td class="text-center"><?= $pm->stok_masuk; ?> Bungkus</td>
                        <td><?= $pm->user_name; ?></td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
</body>

</html>

<script>
    window.print();
</script>