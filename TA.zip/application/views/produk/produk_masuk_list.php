<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Produk Masuk</h1>
    </div>

    <div class="card">
        <?php if($this->uri->segment(2) == "laporan_produk_masuk") { ?>
            <div class="card-header">
                <a href="<?= site_url('laporan/laporan_produk_masuk_print') ?>" class="btn btn-sm btn-primary"><i class="fa fa-print"></i> Print</a>
            </div>
        <?php } ?>
        <div class="card-body">
            <table class="table table-bordered" id="dataTable">
                <thead>
                    <tr>
                        <th class="text-center" style="width: 1%;">No</th>
                        <th>Tanggal Masuk</th>
                        <th>Nama Produk</th>
                        <th class="text-center">Stok Masuk</th>
                        <th>Staff</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $no = 1;
                    foreach ($produk_masuk as $pm) { ?>
                        <tr>
                            <td><?= $no++; ?></td>
                            <td><?= date('d F Y', strtotime($pm->tanggal_masuk)); ?></td>
                            <td><?= $pm->nama; ?></td>
                            <td class="text-center"><?= $pm->stok_masuk; ?> Bungkus</td>
                            <td><?= $pm->user_name; ?></td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
</div>