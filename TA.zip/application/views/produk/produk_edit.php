<!-- Begin Page Content -->
<div class="container-fluid">
    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Edit Produk</h1>
    </div>
    <div class="card">
        <form method="post" action="<?php echo base_url('produk/produk_edit_act'); ?>">
            <?php foreach ($produk as $p) { ?>
                <div class="card-body">
                    <div class="form-group">
                        <div class="row">
                            <label for="nama" class="col-form-label col-md-2">Nama Produk</label>
                            <div class="col-md-10">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text"><i class="fa fa-user"></i></span>
                                    </div>
                                    <input type="hidden" name="id_produk" value="<?= $p->id_produk ?>">
                                    <input type="text" class="form-control" name="nama" value="<?= $p->nama ?>" placeholder="masukkan nama produk.." required>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="row">
                            <label for="harga" class="col-form-label col-md-2">Harga Produk</label>
                            <div class="col-md-10">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text"><i class="fa fa-hand-holding-usd"></i></span>
                                    </div>
                                    <input type="number" class="form-control" name="harga" value="<?= $p->harga ?>" placeholder="masukkan harga produk.." required>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card-footer text-right">
                    <button type="reset" class="btn btn-secondary">Reset</button>
                    <button type="submit" class="btn btn-primary"><i class="fa fa-save"></i> Simpan</button>
                </div>
            <?php } ?>
        </form>
    </div>
</div>