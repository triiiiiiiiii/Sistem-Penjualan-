 <!-- Begin Page Content -->
 <div class="container-fluid">

     <!-- Page Heading -->
     <div class="d-sm-flex align-items-center justify-content-between mb-4">
         <h1 class="h3 mb-0 text-gray-800">Produk List</h1>
     </div>

     <div class="card">
         <?php if ($this->session->userdata('access') == 'Admin') { ?>
             <div class="card-header">
                 <a class="btn btn-primary btn-sm" href="<?php echo base_url() . 'produk/produk_add'; ?>"><i class="fa fa-plus"></i> produk Baru</a>
             </div>
         <?php } ?>
         <div class="card-body">
             <table class="table table-bordered" id="dataTable">
                 <thead>
                     <tr>
                         <th class="text-center" style="width: 1%;">No</th>
                         <th>Nama Produk</th>
                         <th class="text-center">Stok Produk</th>
                         <th class="text-center">Harga</th>
                         <?php if ($this->session->userdata('access') == 'Admin') { ?>
                             <th class="text-center" style="width: 30%;">Aksi</th>
                         <?php } ?>
                     </tr>
                 </thead>
                 <tbody>

                     <?php
                        $no = 1;
                        foreach ($produk as $p) { ?>
                         <tr>
                             <td class="text-center"><?php echo $no++; ?></td>
                             <td><?php echo $p->nama; ?></td>
                             <td class="text-center"><?php echo $p->stok; ?> Bungkus</td>
                             <td class="text-center">Rp.<?= number_format($p->harga, 0, ',', '.') ?>,-</td>
                             <?php if ($this->session->userdata('access') == 'Admin') { ?>
                                 <td class="text-center">
                                     <button type="button" class="btn btn-sm btn-primary" data-toggle="modal" data-target="#modal_stok<?= $p->id_produk; ?>"><i class="fa fa-plus"></i> Tambah Stok</button>
                                     <a class="btn btn-warning btn-sm" href="<?php echo base_url() . 'produk/produk_edit/' . $p->id_produk; ?>"><i class="fa fa-edit"></i> Edit</a>
                                     <a class="btn btn-danger btn-sm" href="<?php echo base_url() . 'produk/delete/' . $p->id_produk; ?>" id="alert-hapus"><i class="fa fa-trash-alt"></i> Hapus</a>
                                 </td>
                             <?php } ?>
                         </tr>
                     <?php } ?>
                 </tbody>
             </table>
         </div>
     </div>
 </div>

 <!-- MODAL TAMBAH PRODUK -->
 <div class="modal fade" id="modal_produk_baru">
     <div class="modal-dialog modal-dialog-centered modal-md">
         <div class="modal-content">
             <div class="modal-header">
                 <h4 class="modal-tittle">Tambah Produk Baru</h4>
                 <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                     <span aria-hidden="true">x</span>
                 </button>
             </div>
             <form method="post" action="<?php echo base_url('produk/produk_add_act'); ?>">
                 <div class="modal-body table-responsive">
                     <div class="form-group">
                         <label for="produk" class="col-form-label">Nama Produk</label>
                         <input type="text" class="form-control" name="nama" placeholder="masukkan nama produk.." required>
                     </div>
                     <div class="form-group">
                         <label for="" class="col-form-lael">Stok Produk</label>
                         <input type="number" class="form-control" name="stok" placeholder="masukkan stok produk.." required>
                     </div>
                     <div class="form-group">
                         <label for="" class="col-form-lael">Harga Produk</label>
                         <input type="number" class="form-control" name="harga" placeholder="masukkan harga produk.." required>
                     </div>
                 </div>
                 <div class="modal-footer">
                     <button type="reset" class="btn btn-secondary">Reset</button>
                     <button type="submit" class="btn btn-primary"><i class="fa fa-save"></i> Simpan</button>
                 </div>
             </form>
         </div>
     </div>
 </div>
 <!-- END MODAL TAMBAH PRODUK -->

 <!-- MODAL EDIT PRODUK -->
 <?php foreach ($produk as $p) { ?>
     <div class="modal fade" id="modal_edit_produk<?= $p->id_produk ?>">
         <div class="modal-dialog modal-dialog-centered modal-md">
             <div class="modal-content">
                 <div class="modal-header">
                     <h4 class="modal-tittle">Edit Produk</h4>
                     <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                         <span aria-hidden="true">x</span>
                     </button>
                 </div>
                 <form method="post" action="<?php echo base_url('produk/produk_edit'); ?>">
                     <div class="modal-body table-responsive">
                         <div class="form-group">
                             <label for="produk" class="col-form-label">Nama Produk</label>
                             <input type="hidden" name="id_produk" value="<?= $p->id_produk ?>">
                             <input type="text" class="form-control" name="nama" value="<?= $p->nama ?>" placeholder="masukkan nama produk.." required>
                         </div>
                         <div class="form-group">
                             <label for="" class="col-form-lael">Harga Produk</label>
                             <input type="number" class="form-control" name="harga" value="<?= $p->harga ?>" placeholder="masukkan harga produk.." required>
                         </div>
                     </div>
                     <div class="modal-footer">
                         <button type="reset" class="btn btn-secondary">Reset</button>
                         <button type="submit" class="btn btn-primary"><i class="fa fa-save"></i> Simpan</button>
                     </div>
                 </form>
             </div>
         </div>
     </div>
 <?php } ?>
 <!-- END MODAL EDIT PRODUK -->

 <!-- MODAL TAMBAH STOK -->
 <?php foreach ($produk as $p) { ?>
     <div class="modal fade" id="modal_stok<?= $p->id_produk ?>">
         <div class="modal-dialog modal-dialog-centered modal-md">
             <div class="modal-content">
                 <div class="modal-header">
                     <h4 class="modal-tittle">Tambah Stok</h4>
                     <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                         <span aria-hidden="true">x</span>
                     </button>
                 </div>
                 <form method="post" action="<?php echo base_url('produk_masuk/tambah_stok'); ?>">
                     <div class="modal-body table-responsive">
                         <div class="form-group">
                             <label for="" class="col-from-label">Tanggal</label>
                             <input type="date" class="form-control" name="tgl_masuk" value="<?= date('Y-m-d') ?>" required>
                         </div>
                         <div class="form-group">
                             <label for="produk" class="col-form-label">Nama Produk</label>
                             <input type="hidden" name="id_produk" value="<?= $p->id_produk ?>">
                             <input type="text" class="form-control" disabled value="<?= $p->nama ?>">
                         </div>
                         <div class="form-group">
                             <label for="" class="col-form-lael">Stok</label>
                             <input type="number" class="form-control" name="stok_masuk" placeholder="masukkan stok masuk.." required>
                         </div>
                     </div>
                     <div class="modal-footer">
                         <button type="reset" class="btn btn-secondary">Reset</button>
                         <button type="submit" class="btn btn-primary"><i class="fa fa-save"></i> Simpan</button>
                     </div>
                 </form>
             </div>
         </div>
     </div>
 <?php } ?>
 <!-- END MODAL TAMBAH STOK -->