 <!-- Begin Page Content -->
 <div class="container-fluid">

     <!-- Page Heading -->
     <div class="d-sm-flex align-items-center justify-content-between mb-4">
         <h1 class="h3 mb-0 text-gray-800">Laporan Transaksi</h1>
     </div>
     <div class="row">
         <div class="col-md-8 mb-4">
             <div class="card">
                 <div class="card-header"><i class="fa fa-filter"></i> Filter</div>
                 <div class="card-body">
                     <form method="get">
                         <div class="row">
                             <div class="col-md-4">
                                 <select class="form-control form-control-sm" name="bulan" id="bulan" required>
                                     <option value="">-- Pilih Bulan --</option>
                                     <?php foreach ($bulan as $b) { ?>
                                         <option value="<?= date('m', mktime(0, 0, 0, $b->bulan, 1)) ?>"><?= date('F', mktime(0, 0, 0, $b->bulan, 1)) ?></option>
                                     <?php } ?>
                                 </select>
                             </div>
                             <div class="col-md-4">
                                 <select class="form-control form-control-sm" name="tahun" id="tahun" required>
                                     <option value="">-- Pilih Tahun --</option>
                                     <?php foreach ($tahun as $t) { ?>
                                         <option value="<?= $t->tahun ?>"><?= $t->tahun ?></option>
                                     <?php } ?>
                                 </select>
                             </div>
                             <div class="col-md-2">
                                 <button type="submit" class="btn btn-sm btn-primary btn-block"><i class="fa fa-search"></i></button>
                             </div>
                             <div class="col-md-2">
                                 <a href="<?= site_url('laporan/laporan_transaksi') ?>" class="btn btn-sm btn-primary btn-block">Semua</a>
                             </div>
                         </div>
                     </form>
                 </div>
             </div>
         </div>
         <?php
            if (isset($_GET['bulan']) && isset($_GET['tahun'])) {
                $bulan = $_GET['bulan'];
                $tahun = $_GET['tahun'];

                // Get Laporan
                $this->db->from('laporan');
                $this->db->where('MONTH(tgl_laporan)', $bulan);
                $this->db->where('YEAR(tgl_laporan)', $tahun);
                $this->db->order_by('tgl_laporan', 'ASC');
                $laporan_filter = $this->db->get()->result();

            ?>
             <div class="col-md-12">
                 <div class="card">
                     <div class="card-header">
                         <a href="<?= site_url('laporan/laporan_per_hari?bulan=' . $bulan . '&tahun=' . $tahun) ?>" target="_blank" class="btn btn-primary btn-sm"><i class="fa fa-book"></i> Semua Laporan / Hari</a>
                         <a href="<?= site_url('laporan/laporan_per_transaksi?bulan=' . $bulan . '&tahun=' . $tahun) ?>" target="_blank" class="btn btn-primary btn-sm"><i class="fa fa-book"></i> Semua Laporan / Transaksi</a>
                     </div>
                     <div class="card-body">
                         <table class="table table-bordered" id="dataTable">
                             <thead>
                                 <tr>
                                     <th style="width: 1%;">No</th>
                                     <th>Tanggal</th>
                                     <th>Jumlah Transaksi</th>
                                     <th>Grand Total</th>
                                     <th style="width: 16%;">Aksi</th>
                                 </tr>
                             </thead>
                             <tbody>
                                 <?php $no = 1;
                                    foreach ($laporan_filter as $l) {
                                        $this->db->select('id_transaksi, COUNT(id_transaksi) as jumlah_transaksi');
                                        $this->db->select('SUM(grand_total) as total_transaksi');
                                        $this->db->from('transaksi');
                                        $this->db->where('DATE_FORMAT(tgl_transaksi, "%Y-%m-%d") =', $l->tgl_laporan);
                                        $transaksi = $this->db->get()->result();
                                        foreach ($transaksi as $t) {
                                            $grand_total = $t->total_transaksi;
                                            $jumlah_transaksi = $t->jumlah_transaksi;
                                        }
                                    ?>
                                     <tr>
                                         <td><?= $no++; ?></td>
                                         <td><?= date('d F Y', strtotime($l->tgl_laporan)); ?></td>
                                         <td><?= $jumlah_transaksi; ?> Transaksi</td>
                                         <td>Rp.<?= number_format($grand_total, 0, ',', '.') ?>,-</td>
                                         <td>
                                             <a href="<?= site_url('laporan/laporan_detail/' . $l->tgl_laporan) ?>" class="btn btn-sm btn-info"><i class="fa fa-list-alt"></i> Detail</a>
                                         </td>
                                     </tr>
                                 <?php } ?>
                             </tbody>
                         </table>
                     </div>
                 </div>
             </div>
         <?php } else { ?>
             <div class="col-md-12">
                 <div class="card">
                     <div class="card-header">
                         <a href="<?= site_url('laporan/laporan_per_hari') ?>" target="_blank" class="btn btn-primary btn-sm"><i class="fa fa-book"></i> Semua Laporan / Hari</a>
                         <a href="<?= site_url('laporan/laporan_per_transaksi') ?>" target="_blank" class="btn btn-primary btn-sm"><i class="fa fa-book"></i> Semua Laporan / Transaksi</a>
                     </div>
                     <div class="card-body">
                         <table class="table table-bordered" id="dataTable">
                             <thead class="bg-dark text-white">
                                 <tr>
                                     <th style="width: 1%;">No</th>
                                     <th>Tanggal</th>
                                     <th>Jumlah Transaksi</th>
                                     <th>Grand Total</th>
                                     <th style="width: 16%;">Aksi</th>
                                 </tr>
                             </thead>
                             <tbody>
                                 <?php $no = 1;
                                    foreach ($laporan as $l) {
                                        $this->db->select('id_transaksi, COUNT(id_transaksi) as jumlah_transaksi');
                                        $this->db->select('SUM(grand_total) as total_transaksi');
                                        $this->db->from('transaksi');
                                        $this->db->where('DATE_FORMAT(tgl_transaksi, "%Y-%m-%d") =', $l->tgl_laporan);
                                        $transaksi = $this->db->get()->result();
                                        foreach ($transaksi as $t) {
                                            $grand_total = $t->total_transaksi;
                                            $jumlah_transaksi = $t->jumlah_transaksi;
                                        }
                                    ?>
                                     <tr>
                                         <td><?= $no++; ?></td>
                                         <td><?= date('d F Y', strtotime($l->tgl_laporan)); ?></td>
                                         <td><?= $jumlah_transaksi; ?> Transaksi</td>
                                         <td>Rp.<?= number_format($grand_total, 0, ',', '.') ?>,-</td>
                                         <td>
                                             <a href="<?= site_url('laporan/laporan_detail/' . $l->tgl_laporan) ?>" class="btn btn-sm btn-info"><i class="fa fa-list-alt"></i> Detail</a>
                                         </td>
                                     </tr>
                                 <?php } ?>
                             </tbody>
                         </table>
                     </div>
                 </div>
             </div>
         <?php } ?>
     </div>
 </div>