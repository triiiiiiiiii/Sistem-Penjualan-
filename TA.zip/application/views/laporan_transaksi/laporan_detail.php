<?php foreach ($laporan as $l) {
    $tgl_laporan = $l->tgl_laporan;
} ?>
<?php foreach ($transaksi as $t) {
    $jumlah_transaksi = $t->jumlah_transaksi;
    $total_transaksi = $t->total_transaksi;
} ?>

<!-- Begin Page Content -->
<div class="container-fluid">
    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Laporan Transaksi Detail</h1>
    </div>
    <div class="card">
        <div class="card-body">
            <table width="100%">
                <tr style="height: 40px;">
                    <td style="width: 20%;">Tanggal</td>
                    <td style="width: 1%;">:</td>
                    <td><?= date('d F Y', strtotime($tgl_laporan)) ?></td>
                </tr>
                <tr style="height: 40px;">
                    <td>Jumlah Transaksi</td>
                    <td>:</td>
                    <td><?= $jumlah_transaksi ?> Transaksi</td>
                </tr>
            </table>
            <br>
            <table class="table" id="dataTable">
                <thead>
                    <th class="text-center">Data Transaksi</th>
                </thead>
                <tbody>
                    <?php
                    $no = 1;
                    foreach ($transaksi_detail as $td) {
                        $this->db->select('id_transaksi, COUNT(id_jumlah_produk) as jumlah_produk');
                        $this->db->from('jumlah_produk_transaksi');
                        $this->db->where('id_transaksi', $td->id_transaksi);
                        $produk = $this->db->get()->result();
                        foreach ($produk as $p) {
                            $jumlah_produk = $p->jumlah_produk;
                        }

                        $this->db->select('*');
                        $this->db->from('jumlah_produk_transaksi');
                        $this->db->join('produk', 'produk.id_produk = jumlah_produk_transaksi.id_produk');
                        $this->db->where('id_transaksi', $td->id_transaksi);
                        $jumlah_p = $this->db->get()->result();
                    ?>
                        <tr>
                            <td>
                                <table class="table table-bordered mb-4">
                                    <thead class="bg-dark text-white">
                                        <th class="text-center" style="width: 1%;">No</th>
                                        <th>Staff</th>
                                        <th colspan="2">Pelanggan</th>
                                        <th class="text-center">Jumlah Produk</th>
                                        <th class="text-center">Status Pengiriman</th>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td class="text-center"><?= $no++ ?></td>
                                            <td><?= $td->user_name ?></td>
                                            <td colspan="2"><?= $td->nama ?></td>
                                            <td class="text-center"><?= $jumlah_produk ?> Produk</td>
                                            <td class="text-center">
                                                <?php if ($td->status_pengiriman == 0) { ?>
                                                    <span class="badge badge-warning">Belum Dikirim</span>
                                                <?php } elseif ($td->status_pengiriman == 1) { ?>
                                                    <span class="badge badge-primary">Sedang Dikirim</span>
                                                <?php } else { ?>
                                                    <span class="badge badge-success">Selesai</span>
                                                <?php } ?>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td colspan="6">
                                                <table class="table">
                                                    <thead>
                                                        <th class="text-center" style="width: 1%;">No</th>
                                                        <th>Nama Produk</th>
                                                        <th class="text-center">QTY</th>
                                                        <th class="text-center">Harga</th>
                                                        <th class="text-center">Total Harga</th>
                                                    </thead>
                                                    <tbody>
                                                        <?php
                                                        $no = 1;
                                                        foreach ($jumlah_p as $jp) { ?>
                                                            <tr>
                                                                <td class="text-center"><?= $no++; ?></td>
                                                                <td><?= $jp->nama ?></td>
                                                                <td class="text-center"><?= $jp->qty ?></td>
                                                                <td class="text-right">Rp.<?= number_format($jp->harga, 0, ',', '.') ?>,-</td>
                                                                <td class="text-right">Rp.<?= number_format($jp->total_harga, 0, ',', '.') ?>,-</td>
                                                            </tr>
                                                        <?php } ?>
                                                    </tbody>
                                                    <thead>
                                                        <th colspan="4" class="text-right">Grand Total :</th>
                                                        <th class="text-right">Rp.<?= number_format($td->total_belanja, 0, ',', '.') ?>,-</th>
                                                    </thead>
                                                </table>
                                            </td>
                                        </tr>
                                    </tbody>
                                    <thead class="bg-secondary text-white">
                                        <th class="text-center" colspan="2">Total Belanja</th>
                                        <th class="text-center">Diskon</th>
                                        <th class="text-center">Grand Total</th>
                                        <th class="text-center">Total Bayar</th>
                                        <th class="text-center">Kembalian</th>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td class="text-right" colspan="2">Rp.<?= number_format($td->total_belanja, 0, ',', '.') ?>,-</td>
                                            <td class="text-right">Rp.<?= number_format($td->diskon, 0, ',', '.') ?>,-</td>
                                            <td class="text-right">Rp.<?= number_format($td->grand_total, 0, ',', '.') ?>,-</td>
                                            <td class="text-right">Rp.<?= number_format($td->bayar, 0, ',', '.') ?>,-</td>
                                            <td class="text-right">Rp.<?= number_format($td->kembalian, 0, ',', '.') ?>,-</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
            <hr>
            <div class="row">
                <div class="col-md-6">
                    <table class="table table-bordered">
                        <thead>
                            <th>Transaksi</th>
                            <th class="text-center">Grand Total</th>
                        </thead>
                        <tbody>
                            <?php
                            $no = 1;
                            foreach ($transaksi_detail as $td) { ?>
                                <tr>
                                    <td>Transaksi <?= $no++ ?></td>
                                    <td class="text-right">Rp.<?= number_format($td->grand_total, 0, ',', '.') ?>,-</td>
                                </tr>
                            <?php } ?>
                            <tr>
                                <th class="text-right">Total :</th>
                                <th class="text-right">Rp.<?= number_format($total_transaksi, 0, ',', '.') ?>,-</th>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <hr>
            <table width="100%">
                <tr>
                    <td style="width: 35%;">Total Omset Pada Tanggal <b><?= date('d F Y', strtotime($tgl_laporan)) ?></b></td>
                    <td style="width: 1%;">:</td>
                    <th>Rp.<?= number_format($total_transaksi, 0, ',', '.') ?>,-</th>
                </tr>
            </table>
        </div>
    </div>
</div>