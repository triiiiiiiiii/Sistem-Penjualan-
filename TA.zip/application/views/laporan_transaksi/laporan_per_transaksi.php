<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CV INTIP KENDIL EMAS</title>
    <link href="<?= base_url('assets/css/bootstrap.min.css') ?>" rel="stylesheet">
    <style>
        .custom-container {
            max-width: 1140px;
            /* Sesuaikan dengan lebar yang Anda inginkan */
            margin: 0 auto;
            /* Memusatkan konten di tengah */
            padding: 0 15px;
            /* Memberikan padding di sisi kiri dan kanan */
        }

        .table-bordered th,
        .table-bordered td {
            font-size: 12px;
        }
    </style>
</head>

<body>
    <br>
    <div class="custom-container">
        <table class="table">
            <thead style="font-size: 18px;">
                <tr class="">
                    <th style="padding: 0px;" class="text-center">LAPORAN TRANSAKSI <br> CV. INTIP KENDIL EMAS <br> <span style="font-size: 12px; font-weight: 400">Dk. Sendangrejo Rt.022, Kel Jati, Kec. Sumberlawang, Kab Sragen, Telp (081335422739) Fax: -</span> </th>
                </tr>
            </thead>
            <tbody>
                <tr></tr>
            </tbody>
        </table>
        <br>
        <?php
        if (isset($_GET['bulan']) && isset($_GET['tahun'])) {
            $bulan = $_GET['bulan'];
            $tahun = $_GET['tahun'];

            // Get Sum Transaksi
            $this->db->select('*');
            $this->db->select('SUM(total_belanja) as total_bealanja');
            $this->db->select('SUM(diskon) as total_diskon');
            $this->db->select('SUM(grand_total) as total_transaksi');
            $this->db->select('SUM(bayar) as total_bayar');
            $this->db->select('SUM(kembalian) as total_kembalian');
            $this->db->from('transaksi');
            $this->db->where('MONTH(tgl_transaksi)', $bulan);
            $this->db->where('YEAR(tgl_transaksi)', $tahun);
            $this->db->order_by('tgl_transaksi', 'ASC');
            $transaksi_filter_sum = $this->db->get()->result();

            foreach ($transaksi_filter_sum as $t) {
                $total_belanja = $t->total_belanja;
                $total_diskon = $t->total_diskon;
                $grand_total = $t->total_transaksi;
                $total_bayar = $t->total_bayar;
                $total_kembalian = $t->total_kembalian;
            }

            // Get Transaksi
            $this->db->select('*');
            $this->db->from('transaksi');
            $this->db->join('pelanggan', 'pelanggan.id_pelanggan=transaksi.id_pelanggan');
            $this->db->join('user', 'user.user_id=transaksi.id_user');
            $this->db->where('MONTH(tgl_transaksi)', $bulan);
            $this->db->where('YEAR(tgl_transaksi)', $tahun);
            $transaksi_filter = $this->db->get()->result();

        ?>
            <h6>Laporan Transaksi Bulan <?= date('F', mktime(0, 0, 0, $bulan, 1)) ?> <?= $tahun ?></h6>
            <table class="table table-bordered" id="dataTable">
                <thead>
                    <tr>
                        <th style="width: 1%;">No</th>
                        <th>Tanggal</th>
                        <th>Staff</th>
                        <th>Pelanggan</th>
                        <th class="text-center">Jumlah Produk</th>
                        <th class="text-center">Total Belanja</th>
                        <th class="text-center">Diskon</th>
                        <th class="text-center">Grand Total</th>
                        <th class="text-center">Total Bayar</th>
                        <th class="text-center">Kembalian</th>
                        <th class="text-center">Status Pengiriman</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $no = 1;
                    foreach ($transaksi_filter as $t) {
                        $this->db->select('id_transaksi, COUNT(id_jumlah_produk) as jumlah_produk');
                        $this->db->from('jumlah_produk_transaksi');
                        $this->db->where('id_transaksi', $t->id_transaksi);
                        $produk = $this->db->get()->result();
                        foreach ($produk as $p) {
                            $jumlah_produk = $p->jumlah_produk;
                        }
                    ?>
                        <tr>
                            <td class="text-center"><?= $no++; ?></td>
                            <td><?= date('d F Y H:i:s', strtotime($t->tgl_transaksi)); ?></td>
                            <td><?= $t->user_name; ?></td>
                            <td><?= $t->nama; ?></td>
                            <td class="text-center"><?= $jumlah_produk; ?> Produk</td>
                            <td style="text-align: right;">Rp.<?= number_format($t->total_belanja, 0, ',', '.') ?>,-</td>
                            <td style="text-align: right;">Rp.<?= number_format($t->diskon, 0, ',', '.') ?>,-</td>
                            <td style="text-align: right;">Rp.<?= number_format($t->grand_total, 0, ',', '.') ?>,-</td>
                            <td style="text-align: right;">Rp.<?= number_format($t->bayar, 0, ',', '.') ?>,-</td>
                            <td style="text-align: right;">Rp.<?= number_format($t->kembalian, 0, ',', '.') ?>,-</td>
                            <td class="text-center">
                                <?php if ($t->status_pengiriman == 0) { ?>
                                    Belum Dikirim
                                <?php } else if ($t->status_pengiriman == 1) { ?>
                                    Sedang Dikirim
                                <?php } else { ?>
                                    Selesai
                                <?php } ?>
                            </td>
                        </tr>
                    <?php } ?>
                </tbody>
                <thead>
                    <th colspan="5">Total :</th>
                    <th style="text-align: right;">Rp.<?= number_format($total_belanja, 0, ',', '.') ?>,-</th>
                    <th style="text-align: right;">Rp.<?= number_format($total_diskon, 0, ',', '.') ?>,-</th>
                    <th style="text-align: right;">Rp.<?= number_format($grand_total, 0, ',', '.') ?>,-</th>
                    <th style="text-align: right;">Rp.<?= number_format($total_bayar, 0, ',', '.') ?>,-</th>
                    <th style="text-align: right;">Rp.<?= number_format($total_kembalian, 0, ',', '.') ?>,-</th>
                    <th></th>
                </thead>
            </table>
        <?php } else { ?>
            <?php foreach ($transaksi_all as $t) {
                $total_belanja = $t->total_belanja;
                $total_diskon = $t->total_diskon;
                $grand_total = $t->total_transaksi;
                $total_bayar = $t->total_bayar;
                $total_kembalian = $t->total_kembalian;
            } ?>
            <h6>Laporan Transaksi Selama Website Dibuat</h6>
            <table class="table table-bordered" id="dataTable">
                <thead>
                    <tr>
                        <th style="width: 1%;">No</th>
                        <th>Tanggal</th>
                        <th>Staff</th>
                        <th>Pelanggan</th>
                        <th class="text-center">Jumlah Produk</th>
                        <th class="text-center">Total Belanja</th>
                        <th class="text-center">Diskon</th>
                        <th class="text-center">Grand Total</th>
                        <th class="text-center">Total Bayar</th>
                        <th class="text-center">Kembalian</th>
                        <th class="text-center">Status Pengiriman</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $no = 1;
                    foreach ($transaksi as $t) {
                        $this->db->select('id_transaksi, COUNT(id_jumlah_produk) as jumlah_produk');
                        $this->db->from('jumlah_produk_transaksi');
                        $this->db->where('id_transaksi', $t->id_transaksi);
                        $produk = $this->db->get()->result();
                        foreach ($produk as $p) {
                            $jumlah_produk = $p->jumlah_produk;
                        }
                    ?>
                        <tr>
                            <td class="text-center"><?= $no++; ?></td>
                            <td><?= date('d F Y H:i:s', strtotime($t->tgl_transaksi)); ?></td>
                            <td><?= $t->user_name; ?></td>
                            <td><?= $t->nama; ?></td>
                            <td class="text-center"><?= $jumlah_produk; ?> Produk</td>
                            <td style="text-align: right;">Rp.<?= number_format($t->total_belanja, 0, ',', '.') ?>,-</td>
                            <td style="text-align: right;">Rp.<?= number_format($t->diskon, 0, ',', '.') ?>,-</td>
                            <td style="text-align: right;">Rp.<?= number_format($t->grand_total, 0, ',', '.') ?>,-</td>
                            <td style="text-align: right;">Rp.<?= number_format($t->bayar, 0, ',', '.') ?>,-</td>
                            <td style="text-align: right;">Rp.<?= number_format($t->kembalian, 0, ',', '.') ?>,-</td>
                            <td class="text-center">
                                <?php if ($t->status_pengiriman == 0) { ?>
                                    Belum Dikirim
                                <?php } else if ($t->status_pengiriman == 1) { ?>
                                    Sedang Dikirim
                                <?php } else { ?>
                                    Selesai
                                <?php } ?>
                            </td>
                        </tr>
                    <?php } ?>
                </tbody>
                <thead>
                    <th colspan="5">Total :</th>
                    <th style="text-align: right;">Rp.<?= number_format($total_belanja, 0, ',', '.') ?>,-</th>
                    <th style="text-align: right;">Rp.<?= number_format($total_diskon, 0, ',', '.') ?>,-</th>
                    <th style="text-align: right;">Rp.<?= number_format($grand_total, 0, ',', '.') ?>,-</th>
                    <th style="text-align: right;">Rp.<?= number_format($total_bayar, 0, ',', '.') ?>,-</th>
                    <th style="text-align: right;">Rp.<?= number_format($total_kembalian, 0, ',', '.') ?>,-</th>
                    <th></th>
                </thead>
            </table>
        <?php } ?>
        <hr>
        <center>" Untuk laporan yang lebih rinci anda dapat melihat detail laporan! "</center>
    </div>
</body>

</html>

<script>
    window.print();
</script>