<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CV INTIP KENDIL EMAS</title>
    <link href="<?= base_url('assets/css/bootstrap.min.css') ?>" rel="stylesheet">
    <style>
        .custom-container {
            max-width: 1140px;
            /* Sesuaikan dengan lebar yang Anda inginkan */
            margin: 0 auto;
            /* Memusatkan konten di tengah */
            padding: 0 15px;
            /* Memberikan padding di sisi kiri dan kanan */
        }

        .table-bordered th,
        .table-bordered td {
            font-size: 12px;
        }
    </style>
</head>

<body>

    <br>
    <div class="custom-container">
        <table class="table">
            <thead style="font-size: 18px;">
                <tr class="">
                    <th style="padding: 0px;" class="text-center">LAPORAN TRANSAKSI <br> CV. INTIP KENDIL EMAS <br> <span style="font-size: 12px; font-weight: 400">Dk. Sendangrejo Rt.022, Kel Jati, Kec. Sumberlawang, Kab Sragen, Telp (081335422739) Fax: -</span> </th>
                </tr>
            </thead>
            <tbody>
                <tr></tr>
            </tbody>
        </table>
        <br>
        <?php
        if (isset($_GET['bulan']) && isset($_GET['tahun'])) {
            $bulan = $_GET['bulan'];
            $tahun = $_GET['tahun'];

            // Get Sum Transaksi
            $this->db->select('*');
            $this->db->select('SUM(grand_total) as total_transaksi');
            $this->db->from('transaksi');
            $this->db->where('MONTH(tgl_transaksi)', $bulan);
            $this->db->where('YEAR(tgl_transaksi)', $tahun);
            $this->db->order_by('tgl_transaksi', 'ASC');
            $transaksi_filter = $this->db->get()->result();

            foreach ($transaksi_filter as $t) {
                $total_transaksi = $t->total_transaksi;
            }

            // Get Laporan
            $this->db->from('laporan');
            $this->db->where('MONTH(tgl_laporan)', $bulan);
            $this->db->where('YEAR(tgl_laporan)', $tahun);
            $this->db->order_by('tgl_laporan', 'ASC');
            $laporan_filter = $this->db->get()->result();

        ?>
            <h6>Laporan Harian Transaksi Bulan <?= date('F', mktime(0, 0, 0, $bulan, 1)) ?> <?= $tahun ?></h6>
            <table class="table table-bordered border-dark">
                <thead>
                    <th class="text-center">No</th>
                    <th>Tanggal Transaksi</th>
                    <th class="text-center">Jumlah Transaksi</th>
                    <th class="text-center">Grand Total</th>
                </thead>
                <tbody>
                    <?php $no = 1;
                    foreach ($laporan_filter as $l) {
                        $this->db->select('id_transaksi, COUNT(id_transaksi) as jumlah_transaksi');
                        $this->db->select('SUM(total_belanja) as total_belanja');
                        $this->db->select('SUM(diskon) as total_diskon');
                        $this->db->select('SUM(grand_total) as total_transaksi');
                        $this->db->select('SUM(bayar) as total_bayar');
                        $this->db->select('SUM(kembalian) as total_kembalian');
                        $this->db->from('transaksi');
                        $this->db->where('DATE_FORMAT(tgl_transaksi, "%Y-%m-%d") =', $l->tgl_laporan);
                        $transaksi = $this->db->get()->result();
                        foreach ($transaksi as $t) {
                            $total_belanja = $t->total_belanja;
                            $diskon = $t->total_diskon;
                            $grand_total = $t->total_transaksi;
                            $total_bayar = $t->total_bayar;
                            $total_kembalian = $t->total_kembalian;
                            $jumlah_transaksi = $t->jumlah_transaksi;
                        }
                    ?>
                        <tr>
                            <td class="text-center"><?= $no++; ?></td>
                            <td><?= date('d F Y', strtotime($l->tgl_laporan)) ?></td>
                            <td class="text-center"><?= $jumlah_transaksi ?> Transaksi</td>
                            <td style="text-align: right;">Rp.<?= number_format($grand_total, 0, ',', '.') ?>,-</td>
                        </tr>
                    <?php } ?>
                </tbody>
                <thead>
                    <tr>
                        <th colspan="3" class="text-end">Total :</th>
                        <th style="text-align: right;">Rp.<?= number_format($total_transaksi, 0, ',', '.') ?>,-</th>
                    </tr>
                </thead>
            </table>
        <?php } else { ?>
            <?php foreach ($transaksi as $t) {
                $jumlah_transaksi = $t->jumlah_transaksi;
                $total_transaksi = $t->total_transaksi;
            } ?>
            <h6>Laporan Harian Transaksi Selama Website Dibuat</h6>
            <table class="table table-bordered border-dark">
                <thead>
                    <th class="text-center">No</th>
                    <th>Tanggal Transaksi</th>
                    <th class="text-center">Jumlah Transaksi</th>
                    <th class="text-center">Grand Total</th>
                </thead>
                <tbody>
                    <?php $no = 1;
                    foreach ($laporan as $l) {
                        $this->db->select('id_transaksi, COUNT(id_transaksi) as jumlah_transaksi');
                        $this->db->select('SUM(total_belanja) as total_belanja');
                        $this->db->select('SUM(diskon) as total_diskon');
                        $this->db->select('SUM(grand_total) as total_transaksi');
                        $this->db->select('SUM(bayar) as total_bayar');
                        $this->db->select('SUM(kembalian) as total_kembalian');
                        $this->db->from('transaksi');
                        $this->db->where('DATE_FORMAT(tgl_transaksi, "%Y-%m-%d") =', $l->tgl_laporan);
                        $transaksi = $this->db->get()->result();
                        foreach ($transaksi as $t) {
                            $total_belanja = $t->total_belanja;
                            $diskon = $t->total_diskon;
                            $grand_total = $t->total_transaksi;
                            $total_bayar = $t->total_bayar;
                            $total_kembalian = $t->total_kembalian;
                            $jumlah_transaksi = $t->jumlah_transaksi;
                        }
                    ?>
                        <tr>
                            <td class="text-center"><?= $no++; ?></td>
                            <td><?= date('d F Y', strtotime($l->tgl_laporan)) ?></td>
                            <td class="text-center"><?= $jumlah_transaksi ?> Transaksi</td>
                            <td style="text-align: right;">Rp.<?= number_format($grand_total, 0, ',', '.') ?>,-</td>
                        </tr>
                    <?php } ?>
                </tbody>
                <thead>
                    <tr>
                        <th colspan="3" class="text-end">Total :</th>
                        <th style="text-align: right;">Rp.<?= number_format($total_transaksi, 0, ',', '.') ?>,-</th>
                    </tr>
                </thead>
            </table>
        <?php } ?>
        <hr>
        <center>" Untuk laporan yang lebih rinci anda dapat melihat laporan transaksi harian! "</center>
    </div>
</body>

</html>

<script>
    window.print();
</script>