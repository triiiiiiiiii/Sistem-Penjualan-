 <!-- Begin Page Content -->
 <div class="container-fluid">

     <!-- Page Heading -->
     <div class="d-sm-flex align-items-center justify-content-between mb-4">
         <h1 class="h3 mb-0 text-gray-800">Pengiriman List</h1>
     </div>

     <div class="card">
         <div class="card-body">
             <table class="table table-bordered" id="dataTable">
                 <thead>
                     <tr>
                         <th style="width: 1%;">No</th>
                         <th>Tanggal Transaksi</th>
                         <th>Tanggal Kirim</th>
                         <th>Tanggal Sampai</th>
                         <th>Pelanggan</th>
                         <th class="text-center">Jumlah Produk</th>
                         <th class="text-center">Grand Total</th>
                         <th class="text-center">Status</th>
                         <th class="text-center" style="width: 20%;">Aksi</th>
                     </tr>
                 </thead>
                 <tbody>
                     <?php $no = 1;
                        foreach ($pengiriman as $t) {
                            $this->db->select('id_transaksi, COUNT(id_jumlah_produk) as jumlah_produk');
                            $this->db->from('jumlah_produk_transaksi');
                            $this->db->where('id_transaksi', $t->id_transaksi);
                            $produk = $this->db->get()->result();
                            foreach ($produk as $p) {
                                $jumlah_produk = $p->jumlah_produk;
                            }
                        ?>
                         <tr>
                             <td class="text-center"><?= $no++; ?></td>
                             <td><?= date('d F Y H:i:s', strtotime($t->tgl_transaksi)); ?></td>
                             <td><?= date('d F Y H:i:s', strtotime($t->tgl_kirim)); ?></td>
                             <td>
                                 <?php if ($t->tgl_sampai == '0000-00-00 00:00:00') { ?>
                                     -
                                 <?php } else { ?>
                                     <?= date('d F Y H:i:s', strtotime($t->tgl_sampai)); ?>
                                 <?php } ?>
                             </td>
                             <td><?= $t->nama; ?></td>
                             <td class="text-center"><?= $jumlah_produk; ?> Produk</td>
                             <td class="text-center">Rp.<?= number_format($t->grand_total, 0, ',', '.') ?>,-</td>
                             <td class="text-center">
                                 <?php if ($t->status_pengiriman == 1) { ?>
                                     <span class=" badge badge-primary"><i class="fa"></i> Sedang Dikirim</span>
                                 <?php } else { ?>
                                     <span class=" badge badge-success">Selesai</span>
                                 <?php } ?>
                             </td>
                             <td class="text-center">
                                 <a href="<?= site_url('pengiriman/pengiriman_detail/' . $t->id_pengiriman) ?>" class="btn btn-sm btn-info"><i class="fa fa-list-alt"></i> Detail</a>
                                 <?php if ($t->tgl_sampai == '0000-00-00 00:00:00') { ?>
                                     <a href="<?= site_url('pengiriman/selesaikan/'. $t->id_transaksi) ?>" class="btn btn-sm btn-success" id="alert-selesai-kirim"><i class="fa fa-check"></i> Selesaikan</a>
                                 <?php } ?>
                             </td>
                         </tr>
                     <?php } ?>
                 </tbody>
             </table>
         </div>
     </div>
 </div>